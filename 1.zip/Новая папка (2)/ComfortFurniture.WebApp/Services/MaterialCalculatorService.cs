namespace ComfortFurniture.WebApp.Services;

public sealed class MaterialCalculatorService
{
    private readonly SqliteConnectionFactory _connectionFactory;

    public MaterialCalculatorService(SqliteConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public int CalculateRequiredMaterial(
        int productTypeId,
        int materialTypeId,
        int productCount,
        double parameter1,
        double parameter2)
    {
        if (productTypeId <= 0
            || materialTypeId <= 0
            || productCount <= 0
            || parameter1 <= 0
            || parameter2 <= 0)
        {
            return -1;
        }

        const string productTypeSql = @"
            SELECT Coefficient
            FROM ProductTypes
            WHERE ProductTypeId = $productTypeId;";

        const string materialTypeSql = @"
            SELECT WastePercentage
            FROM MaterialTypes
            WHERE MaterialTypeId = $materialTypeId;";

        using var connection = _connectionFactory.CreateConnection();

        using var productTypeCommand = connection.CreateCommand();
        productTypeCommand.CommandText = productTypeSql;
        productTypeCommand.Parameters.AddWithValue("$productTypeId", productTypeId);

        using var materialTypeCommand = connection.CreateCommand();
        materialTypeCommand.CommandText = materialTypeSql;
        materialTypeCommand.Parameters.AddWithValue("$materialTypeId", materialTypeId);

        var coefficientValue = productTypeCommand.ExecuteScalar();
        var wasteValue = materialTypeCommand.ExecuteScalar();

        if (coefficientValue is null || wasteValue is null)
        {
            return -1;
        }

        var coefficient = Convert.ToDouble(coefficientValue);
        var wastePercentage = Convert.ToDouble(wasteValue);

        var rawPerUnit = parameter1 * parameter2 * coefficient;
        var rawWithoutWaste = rawPerUnit * productCount;
        var rawWithWaste = rawWithoutWaste * (1 + wastePercentage);

        if (double.IsNaN(rawWithWaste) || double.IsInfinity(rawWithWaste) || rawWithWaste > int.MaxValue)
        {
            return -1;
        }

        var result = (int)Math.Ceiling(rawWithWaste);

        return result < 0 ? -1 : result;
    }
}
