using ComfortFurniture.WebApp.ViewModels;

namespace ComfortFurniture.WebApp.Services;

public sealed class WorkshopRepository
{
    private readonly SqliteConnectionFactory _connectionFactory;

    public WorkshopRepository(SqliteConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public ProductWorkshopsPageViewModel? GetProductWorkshops(int productId)
    {
        var productName = GetProductName(productId);

        if (string.IsNullOrWhiteSpace(productName))
        {
            return null;
        }

        const string sql = @"
            SELECT
                w.Name,
                w.WorkshopType,
                w.EmployeeCount,
                pw.ProductionHours
            FROM ProductWorkshops pw
            INNER JOIN Workshops w ON w.WorkshopId = pw.WorkshopId
            WHERE pw.ProductId = $productId
            ORDER BY w.Name;";

        var workshops = new List<WorkshopListItemViewModel>();

        using var connection = _connectionFactory.CreateConnection();
        using var command = connection.CreateCommand();

        command.CommandText = sql;
        command.Parameters.AddWithValue("$productId", productId);

        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            workshops.Add(new WorkshopListItemViewModel
            {
                Name = reader.GetString(0),
                WorkshopType = reader.GetString(1),
                EmployeeCount = reader.GetInt32(2),
                ProductionHours = reader.GetDouble(3)
            });
        }

        return new ProductWorkshopsPageViewModel
        {
            ProductId = productId,
            ProductName = productName,
            Workshops = workshops
        };
    }

    private string? GetProductName(int productId)
    {
        const string sql = "SELECT Name FROM Products WHERE ProductId = $productId;";

        using var connection = _connectionFactory.CreateConnection();
        using var command = connection.CreateCommand();

        command.CommandText = sql;
        command.Parameters.AddWithValue("$productId", productId);

        var result = command.ExecuteScalar();

        return result?.ToString();
    }
}
