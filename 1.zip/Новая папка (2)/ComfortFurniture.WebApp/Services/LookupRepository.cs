using ComfortFurniture.WebApp.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ComfortFurniture.WebApp.Services;

public sealed class LookupRepository
{
    private readonly SqliteConnectionFactory _connectionFactory;

    public LookupRepository(SqliteConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public DashboardSummaryViewModel GetDashboardSummary()
    {
        const string sql = @"
            SELECT
                (SELECT COUNT(*) FROM Products) AS ProductCount,
                (SELECT COUNT(*) FROM Workshops) AS WorkshopCount,
                (SELECT COUNT(*) FROM MaterialTypes) AS MaterialTypeCount;";

        using var connection = _connectionFactory.CreateConnection();
        using var command = connection.CreateCommand();

        command.CommandText = sql;

        using var reader = command.ExecuteReader();

        if (!reader.Read())
        {
            return new DashboardSummaryViewModel();
        }

        return new DashboardSummaryViewModel
        {
            ProductCount = reader.GetInt32(0),
            WorkshopCount = reader.GetInt32(1),
            MaterialTypeCount = reader.GetInt32(2)
        };
    }

    public IReadOnlyList<SelectListItem> GetProductTypeOptions(int selectedId = 0)
    {
        return LoadOptions(
            "SELECT ProductTypeId, Name FROM ProductTypes ORDER BY Name;",
            selectedId);
    }

    public IReadOnlyList<SelectListItem> GetMaterialTypeOptions(int selectedId = 0)
    {
        return LoadOptions(
            "SELECT MaterialTypeId, Name FROM MaterialTypes ORDER BY Name;",
            selectedId);
    }

    private IReadOnlyList<SelectListItem> LoadOptions(string sql, int selectedId)
    {
        var items = new List<SelectListItem>();

        using var connection = _connectionFactory.CreateConnection();
        using var command = connection.CreateCommand();

        command.CommandText = sql;

        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            var id = reader.GetInt32(0);

            items.Add(new SelectListItem
            {
                Value = id.ToString(),
                Text = reader.GetString(1),
                Selected = id == selectedId
            });
        }

        return items;
    }
}
