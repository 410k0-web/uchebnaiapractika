namespace ComfortFurniture.WebApp.Services;

public sealed class DatabaseBootstrapper
{
    private readonly IWebHostEnvironment _environment;
    private readonly IConfiguration _configuration;

    public DatabaseBootstrapper(IWebHostEnvironment environment, IConfiguration configuration)
    {
        _environment = environment;
        _configuration = configuration;
    }

    public void EnsureDatabaseCreated()
    {
        var targetPath = ResolveDatabasePath();
        var targetDirectory = Path.GetDirectoryName(targetPath);

        if (!string.IsNullOrWhiteSpace(targetDirectory))
        {
            Directory.CreateDirectory(targetDirectory);
        }

        if (File.Exists(targetPath))
        {
            return;
        }

        var seedPath = Path.Combine(_environment.ContentRootPath, "Data", "Seed", "comfort.db");

        if (!File.Exists(seedPath))
        {
            throw new FileNotFoundException("Не найден шаблон базы данных.", seedPath);
        }

        File.Copy(seedPath, targetPath);
    }

    private string ResolveDatabasePath()
    {
        var connectionString = _configuration.GetConnectionString("DefaultConnection")
            ?? "Data Source=App_Data/comfort.db";

        const string prefix = "Data Source=";

        if (!connectionString.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
        {
            return Path.Combine(_environment.ContentRootPath, "App_Data", "comfort.db");
        }

        var relativePath = connectionString[prefix.Length..].Trim();

        if (Path.IsPathRooted(relativePath))
        {
            return relativePath;
        }

        return Path.Combine(_environment.ContentRootPath, relativePath);
    }
}
