using ComfortFurniture.WebApp.ViewModels;
using Microsoft.Data.Sqlite;

namespace ComfortFurniture.WebApp.Services;

public sealed class ProductRepository
{
    private readonly SqliteConnectionFactory _connectionFactory;

    public ProductRepository(SqliteConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public IReadOnlyList<ProductListItemViewModel> GetProducts()
    {
        const string sql = @"
            SELECT
                p.ProductId,
                p.Article,
                pt.Name AS ProductTypeName,
                p.Name,
                p.PartnerMinPrice,
                mt.Name AS MaterialTypeName,
                COALESCE(SUM(pw.ProductionHours), 0) AS TotalProductionHours
            FROM Products p
            INNER JOIN ProductTypes pt ON pt.ProductTypeId = p.ProductTypeId
            INNER JOIN MaterialTypes mt ON mt.MaterialTypeId = p.MaterialTypeId
            LEFT JOIN ProductWorkshops pw ON pw.ProductId = p.ProductId
            GROUP BY
                p.ProductId,
                p.Article,
                pt.Name,
                p.Name,
                p.PartnerMinPrice,
                mt.Name
            ORDER BY pt.Name, p.Name;";

        var products = new List<ProductListItemViewModel>();

        using var connection = _connectionFactory.CreateConnection();
        using var command = connection.CreateCommand();

        command.CommandText = sql;

        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            products.Add(new ProductListItemViewModel
            {
                ProductId = reader.GetInt32(0),
                Article = reader.GetInt32(1),
                ProductTypeName = reader.GetString(2),
                Name = reader.GetString(3),
                PartnerMinPrice = reader.GetDecimal(4),
                MaterialTypeName = reader.GetString(5),
                TotalProductionHours = reader.GetDouble(6)
            });
        }

        return products;
    }

    public ProductEditorViewModel? GetProductForEdit(int productId)
    {
        const string sql = @"
            SELECT
                ProductId,
                Article,
                ProductTypeId,
                Name,
                PartnerMinPrice,
                MaterialTypeId
            FROM Products
            WHERE ProductId = $productId;";

        using var connection = _connectionFactory.CreateConnection();
        using var command = connection.CreateCommand();

        command.CommandText = sql;
        command.Parameters.AddWithValue("$productId", productId);

        using var reader = command.ExecuteReader();

        if (!reader.Read())
        {
            return null;
        }

        return new ProductEditorViewModel
        {
            ProductId = reader.GetInt32(0),
            Article = reader.GetInt32(1),
            ProductTypeId = reader.GetInt32(2),
            Name = reader.GetString(3),
            PartnerMinPrice = reader.GetDecimal(4),
            MaterialTypeId = reader.GetInt32(5)
        };
    }

    public void CreateProduct(ProductEditorViewModel model)
    {
        const string sql = @"
            INSERT INTO Products
                (Article, ProductTypeId, Name, PartnerMinPrice, MaterialTypeId)
            VALUES
                ($article, $productTypeId, $name, $partnerMinPrice, $materialTypeId);";

        using var connection = _connectionFactory.CreateConnection();
        using var command = connection.CreateCommand();

        command.CommandText = sql;
        FillProductParameters(command, model);

        command.ExecuteNonQuery();
    }

    public bool UpdateProduct(ProductEditorViewModel model)
    {
        if (!model.ProductId.HasValue)
        {
            return false;
        }

        const string sql = @"
            UPDATE Products
            SET
                Article = $article,
                ProductTypeId = $productTypeId,
                Name = $name,
                PartnerMinPrice = $partnerMinPrice,
                MaterialTypeId = $materialTypeId
            WHERE ProductId = $productId;";

        using var connection = _connectionFactory.CreateConnection();
        using var command = connection.CreateCommand();

        command.CommandText = sql;
        command.Parameters.AddWithValue("$productId", model.ProductId.Value);
        FillProductParameters(command, model);

        return command.ExecuteNonQuery() > 0;
    }

    private static void FillProductParameters(SqliteCommand command, ProductEditorViewModel model)
    {
        command.Parameters.AddWithValue("$article", model.Article);
        command.Parameters.AddWithValue("$productTypeId", model.ProductTypeId);
        command.Parameters.AddWithValue("$name", model.Name.Trim());
        command.Parameters.AddWithValue("$partnerMinPrice", model.PartnerMinPrice);
        command.Parameters.AddWithValue("$materialTypeId", model.MaterialTypeId);
    }
}
