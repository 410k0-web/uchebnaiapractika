using Microsoft.Data.Sqlite;

namespace ComfortFurniture.WebApp.Services;

public sealed class SqliteConnectionFactory
{
    private readonly IWebHostEnvironment _environment;
    private readonly IConfiguration _configuration;

    public SqliteConnectionFactory(IWebHostEnvironment environment, IConfiguration configuration)
    {
        _environment = environment;
        _configuration = configuration;
    }

    public SqliteConnection CreateConnection()
    {
        var connectionString = BuildConnectionString();
        var connection = new SqliteConnection(connectionString);

        connection.Open();

        using var pragmaCommand = connection.CreateCommand();
        pragmaCommand.CommandText = "PRAGMA foreign_keys = ON;";
        pragmaCommand.ExecuteNonQuery();

        return connection;
    }

    private string BuildConnectionString()
    {
        var rawConnectionString = _configuration.GetConnectionString("DefaultConnection")
            ?? "Data Source=App_Data/comfort.db";

        const string prefix = "Data Source=";

        if (!rawConnectionString.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
        {
            return rawConnectionString;
        }

        var dbPath = rawConnectionString[prefix.Length..].Trim();

        if (!Path.IsPathRooted(dbPath))
        {
            dbPath = Path.Combine(_environment.ContentRootPath, dbPath);
        }

        return $"{prefix}{dbPath}";
    }
}
