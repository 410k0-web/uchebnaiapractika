using ComfortFurniture.WebApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace ComfortFurniture.WebApp.Controllers;

public sealed class HomeController : Controller
{
    private readonly LookupRepository _lookupRepository;

    public HomeController(LookupRepository lookupRepository)
    {
        _lookupRepository = lookupRepository;
    }

    public IActionResult Index()
    {
        ViewData["Title"] = "Главная";
        var model = _lookupRepository.GetDashboardSummary();

        return View(model);
    }

    public IActionResult Error()
    {
        ViewData["Title"] = "Ошибка";

        return View();
    }
}
