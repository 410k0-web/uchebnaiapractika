using ComfortFurniture.WebApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace ComfortFurniture.WebApp.Controllers;

public sealed class WorkshopsController : Controller
{
    private readonly WorkshopRepository _workshopRepository;

    public WorkshopsController(WorkshopRepository workshopRepository)
    {
        _workshopRepository = workshopRepository;
    }

    public IActionResult Index(int productId)
    {
        var model = _workshopRepository.GetProductWorkshops(productId);

        if (model is null)
        {
            TempData["StatusMessage"] = "Не удалось загрузить список цехов.";

            return RedirectToAction("Index", "Products");
        }

        ViewData["Title"] = "Цеха производства";

        return View(model);
    }
}
