using ComfortFurniture.WebApp.Services;
using ComfortFurniture.WebApp.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace ComfortFurniture.WebApp.Controllers;

public sealed class MaterialsController : Controller
{
    private readonly LookupRepository _lookupRepository;
    private readonly MaterialCalculatorService _materialCalculatorService;

    public MaterialsController(
        LookupRepository lookupRepository,
        MaterialCalculatorService materialCalculatorService)
    {
        _lookupRepository = lookupRepository;
        _materialCalculatorService = materialCalculatorService;
    }

    [HttpGet]
    public IActionResult Index()
    {
        ViewData["Title"] = "Калькулятор сырья";
        var model = Populate(new MaterialCalculatorViewModel());

        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Index(MaterialCalculatorViewModel model)
    {
        ViewData["Title"] = "Калькулятор сырья";

        if (!ModelState.IsValid)
        {
            return View(Populate(model));
        }

        var result = _materialCalculatorService.CalculateRequiredMaterial(
            model.ProductTypeId,
            model.MaterialTypeId,
            model.ProductCount,
            model.Parameter1,
            model.Parameter2);

        if (result < 0)
        {
            ModelState.AddModelError(
                string.Empty,
                "Не удалось выполнить расчет. Проверьте параметры и справочники.");

            return View(Populate(model));
        }

        model.Result = result;
        model.Message = "Расчет выполнен по формуле с учетом коэффициента типа продукции и процента потерь сырья.";

        return View(Populate(model));
    }

    private MaterialCalculatorViewModel Populate(MaterialCalculatorViewModel model)
    {
        model.ProductTypes = _lookupRepository.GetProductTypeOptions(model.ProductTypeId);
        model.MaterialTypes = _lookupRepository.GetMaterialTypeOptions(model.MaterialTypeId);

        return model;
    }
}
