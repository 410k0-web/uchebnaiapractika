using ComfortFurniture.WebApp.Services;
using ComfortFurniture.WebApp.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace ComfortFurniture.WebApp.Controllers;

public sealed class ProductsController : Controller
{
    private readonly ProductRepository _productRepository;
    private readonly LookupRepository _lookupRepository;

    public ProductsController(
        ProductRepository productRepository,
        LookupRepository lookupRepository)
    {
        _productRepository = productRepository;
        _lookupRepository = lookupRepository;
    }

    public IActionResult Index()
    {
        ViewData["Title"] = "Список продукции";
        var products = _productRepository.GetProducts();

        return View(products);
    }

    [HttpGet]
    public IActionResult Create()
    {
        ViewData["Title"] = "Добавление продукции";
        var model = PopulateEditor(new ProductEditorViewModel(), false);

        return View("Edit", model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(ProductEditorViewModel model)
    {
        ViewData["Title"] = "Добавление продукции";

        if (!ModelState.IsValid)
        {
            return View("Edit", PopulateEditor(model, false));
        }

        _productRepository.CreateProduct(model);
        TempData["StatusMessage"] = "Продукция успешно добавлена.";

        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public IActionResult Edit(int id)
    {
        var model = _productRepository.GetProductForEdit(id);

        if (model is null)
        {
            TempData["StatusMessage"] = "Продукция не найдена.";

            return RedirectToAction(nameof(Index));
        }

        ViewData["Title"] = "Редактирование продукции";

        return View(PopulateEditor(model, true));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(ProductEditorViewModel model)
    {
        ViewData["Title"] = "Редактирование продукции";

        if (!ModelState.IsValid)
        {
            return View(PopulateEditor(model, true));
        }

        var isUpdated = _productRepository.UpdateProduct(model);

        if (!isUpdated)
        {
            TempData["StatusMessage"] = "Не удалось сохранить изменения.";

            return RedirectToAction(nameof(Index));
        }

        TempData["StatusMessage"] = "Изменения сохранены.";

        return RedirectToAction(nameof(Index));
    }

    private ProductEditorViewModel PopulateEditor(ProductEditorViewModel model, bool isEdit)
    {
        model.PageTitle = isEdit
            ? "Редактирование продукта"
            : "Добавление продукта";

        model.SubmitButtonText = isEdit
            ? "Сохранить изменения"
            : "Добавить продукт";

        model.ProductTypes = _lookupRepository.GetProductTypeOptions(model.ProductTypeId);
        model.MaterialTypes = _lookupRepository.GetMaterialTypeOptions(model.MaterialTypeId);

        return model;
    }
}
