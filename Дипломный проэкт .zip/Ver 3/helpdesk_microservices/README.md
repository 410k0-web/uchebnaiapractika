# Helpdesk (microservices)

Состав:
1) **Helpdesk.Collector** — центральный сервис + SQLite + outbox (данные не теряются, даже если часть сервисов выключена)
2) **Helpdesk.Bot.Telegram** — Telegram-бот (читает outbox и отправляет сообщения)
3) **Helpdesk.Web.Helper** — веб-интерфейс хелперов / супер-админов
4) **Helpdesk.Web.Client** — веб-интерфейс клиента для создания тикетов и чата

## Быстрый старт (Docker)

1. В `docker-compose.yml` заполните:
   - `Telegram__BotToken`
   - `Telegram__SupportChatId`
   - (опционально) `Telegram__HelperUsernames` (через запятую)

2. Запуск:

```bash
docker compose up --build
```

3. Адреса:
- Collector (Swagger): `http://localhost:7000/swagger`
- Helper Web: `http://localhost:7001`
- Client Web: `http://localhost:7002`

## Логин в админку

По умолчанию супер-админ (создаётся при первом запуске, если база пустая):
- логин: `AIOKO`
- пароль: `1337`

## Visual Studio 2022

Откройте решение `Helpdesk.Microservices.sln`.

Для локального запуска без Docker:
- Запустите `Helpdesk.Collector`
- В `appsettings.json` в веб-проектах укажите `Collector:BaseUrl` и `Collector:PublicBaseUrl` (например `http://localhost:7000`)
- Запустите `Helpdesk.Web.Helper` и/или `Helpdesk.Web.Client`
- Для Telegram-бота укажите `Telegram:BotToken` и `Telegram:SupportChatId` в `Helpdesk.Bot.Telegram/appsettings.json`

## Важно

Все сообщения между сервисами идут через Collector (HTTP). Collector хранит:
- тикеты + сообщения
- файлы (/uploads)
- outbox для Telegram (сообщения на отправку)

Если бот или веб-сервисы выключены, данные **не теряются**: они сохраняются в Collector и будут доставлены после запуска сервиса.