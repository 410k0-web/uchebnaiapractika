using System.Collections.Generic;
using Helpdesk.Shared.Models;

namespace Helpdesk.Shared.Contracts;

public class CreateTicketRequest
{
    /// <summary>
    /// telegram | web
    /// </summary>
    public string Source { get; set; } = "web";

    // Telegram specific
    public long TelegramUserId { get; set; }
    public string? TelegramUsername { get; set; }
    public string? TelegramFullName { get; set; }

    /// <summary>
    /// Для web-клиента (не Telegram). Если не задано, будет взято из TelegramFullName.
    /// </summary>
    public string? FullName { get; set; }

    // Common fields
    public string Reason { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string AccountNumber { get; set; } = string.Empty;
    public string ProblemType { get; set; } = string.Empty;
    public string Comment { get; set; } = string.Empty;

    public List<AttachmentItem>? Attachments { get; set; }
    public string? Photo { get; set; }
}

public class AddMessageRequest
{
    public string FromRole { get; set; } = "user";
    public long? FromUserId { get; set; }
    public string? FromUsername { get; set; }
    public string? Text { get; set; }
    public List<AttachmentItem>? Attachments { get; set; }

    public bool EnqueueToTelegramUser { get; set; }
    public bool EnqueueToSupportChat { get; set; }
}

public class AssignTicketRequest
{
    public long HelperTelegramId { get; set; }
    public string? HelperName { get; set; }
    public string? HelperUsername { get; set; }
}

public class CloseRequest
{
    public string RequestedBy { get; set; } = "helper"; // helper / system / user
}

public class AccountLoginRequest
{
    public string Login { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}

public class FileUploadResponse
{
    public string Url { get; set; } = string.Empty; // /uploads/...
    public string StoredFileName { get; set; } = string.Empty;
    public string? OriginalFileName { get; set; }
    public string? ContentType { get; set; }
}
