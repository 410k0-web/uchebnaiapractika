using System.ComponentModel.DataAnnotations;

namespace Helpdesk.Shared.Models;

public class Account
{
    public int Id { get; set; }

    [Required]
    [MaxLength(50)]
    public string Login { get; set; } = string.Empty;

    [Required]
    [MaxLength(100)]
    public string Password { get; set; } = string.Empty; // демо: без хеша

    [MaxLength(100)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(100)]
    public string LastName { get; set; } = string.Empty;

    [MaxLength(20)]
    public string? Phone { get; set; }

    [Required]
    [MaxLength(20)]
    public string Role { get; set; } = AccountRole.Helper;
}

public static class AccountRole
{
    public const string Helper = "Helper";
    public const string SuperAdmin = "SuperAdmin";
}
