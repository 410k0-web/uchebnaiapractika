using System;
using System.Collections.Generic;

namespace Helpdesk.Shared.Models;

public enum TelegramConversationStep
{
    None = 0,
    Reason = 1,
    Phone = 2,
    AccountNumber = 3,
    ProblemType = 4,
    Comment = 5,
    Attachments = 6
}

public class TicketDraft
{
    public string Reason { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string AccountNumber { get; set; } = string.Empty;
    public string ProblemType { get; set; } = string.Empty;
    public string Comment { get; set; } = string.Empty;

    // Для Telegram сюда кладём AttachmentItem с FileId
    public List<AttachmentItem> Attachments { get; set; } = new();
}

public class TelegramUserSession
{
    public long UserId { get; set; }
    public string? Username { get; set; }

    public TelegramConversationStep Step { get; set; } = TelegramConversationStep.None;

    // JSON (TicketDraft)
    public string DraftJson { get; set; } = "{}";

    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}
