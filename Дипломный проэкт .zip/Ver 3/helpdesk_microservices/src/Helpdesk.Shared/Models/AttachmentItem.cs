namespace Helpdesk.Shared.Models;

/// <summary>
/// Унифицированное описание вложения в TicketMessage.AttachmentsJson.
///
/// * Для Telegram: Type + FileId (+ FileName)
/// * Для WEB:     Type + Url    (+ FileName)
/// </summary>
public class AttachmentItem
{
    public string Type { get; set; } = string.Empty; // photo / document / video
    public string? FileId { get; set; }
    public string? Url { get; set; }
    public string? FileName { get; set; }
}
