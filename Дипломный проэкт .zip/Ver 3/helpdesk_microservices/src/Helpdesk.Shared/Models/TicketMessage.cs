using System;
using System.Text.Json.Serialization;

namespace Helpdesk.Shared.Models;

public class TicketMessage
{
    public int Id { get; set; }

    public int TicketId { get; set; }

    // EF Core navigation property.
    // Ignored in JSON to prevent cycles: Ticket -> Messages -> Ticket ...
    [JsonIgnore]
    public Ticket? Ticket { get; set; }

    public long? FromUserId { get; set; }
    public string? FromUsername { get; set; }

    // user / helper / client / system
    public string FromRole { get; set; } = string.Empty;

    public string? Text { get; set; }

    // JSON (AttachmentItem[])
    public string? AttachmentsJson { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
