using System;
using System.Collections.Generic;

namespace Helpdesk.Shared.Models;

public class Ticket
{
    public int Id { get; set; }

    // Telegram user id (если через бота) или 0, если тикет создан через веб-сайт
    public long UserId { get; set; }
    public string? Username { get; set; }
    public string? FullName { get; set; }

    public string Reason { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string AccountNumber { get; set; } = string.Empty;
    public string ProblemType { get; set; } = string.Empty;
    public string Comment { get; set; } = string.Empty;

    // Ссылка/описание фото/скрина (для веб-клиента или текстовая ссылка)
    public string? Photo { get; set; }

    // JSON с вложениями из Telegram/WEB
    public string? AttachmentsJson { get; set; }

    // open / closed
    public string Status { get; set; } = TicketStatus.Open;
    public long? HelperId { get; set; }
    public string? HelperName { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ClosedAt { get; set; }

    public DateTime? WorkStartedAt { get; set; }
    public DateTime? LastCloseRequestAt { get; set; }

    public bool CloseConfirmationPending { get; set; }
    public DateTime? CloseConfirmationRequestedAt { get; set; }

    public List<TicketMessage> Messages { get; set; } = new();
}

public static class TicketStatus
{
    public const string Open = "open";
    public const string Closed = "closed";
}
