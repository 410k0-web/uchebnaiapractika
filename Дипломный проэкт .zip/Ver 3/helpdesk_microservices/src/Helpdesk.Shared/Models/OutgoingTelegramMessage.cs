using System;

namespace Helpdesk.Shared.Models;

public static class OutgoingMessageStatus
{
    public const string Pending = "pending";
    public const string Sent = "sent";
    public const string Failed = "failed";
}

/// <summary>
/// Очередь исходящих сообщений в Telegram.
/// Это ключевой механизм, который гарантирует, что сообщения от Web-сервисов не потеряются,
/// даже если Telegram-бот временно выключен.
/// </summary>
public class OutgoingTelegramMessage
{
    public long Id { get; set; }

    public long ChatId { get; set; }
    public int? TicketId { get; set; }

    /// <summary>
    /// text | close_request
    /// </summary>
    public string Type { get; set; } = "text";

    public string? Text { get; set; }

    // JSON (AttachmentItem[])
    public string? AttachmentsJson { get; set; }

    // JSON (любая доп. нагрузка: например ticketId для клавиатур)
    public string? PayloadJson { get; set; }

    public string Status { get; set; } = OutgoingMessageStatus.Pending;

    public int Attempts { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? NextAttemptAt { get; set; }
    public DateTime? SentAt { get; set; }
    public string? LastError { get; set; }
}
