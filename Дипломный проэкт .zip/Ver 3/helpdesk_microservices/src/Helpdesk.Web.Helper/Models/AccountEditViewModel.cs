using System.ComponentModel.DataAnnotations;
using Helpdesk.Shared.Models;

namespace Helpdesk.Web.Helper.Models;

public class AccountEditViewModel
{
    public int? Id { get; set; }

    [Required]
    public string Login { get; set; } = string.Empty;

    [Required]
    public string Name { get; set; } = string.Empty;

    [Required]
    public string LastName { get; set; } = string.Empty;

    public string? Phone { get; set; }

    [Required]
    public string Role { get; set; } = AccountRole.Helper;

    // При создании обязателен, при редактировании — опционален
    public string? Password { get; set; }
}
