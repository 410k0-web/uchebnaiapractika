using System.ComponentModel.DataAnnotations;

namespace Helpdesk.Web.Helper.Models;

public class ProfileViewModel
{
    public int Id { get; set; }

    [Required]
    public string Login { get; set; } = string.Empty;

    [Required]
    public string Name { get; set; } = string.Empty;

    [Required]
    public string LastName { get; set; } = string.Empty;

    public string? Phone { get; set; }

    public string? NewPassword { get; set; }
    public string? ConfirmPassword { get; set; }
}
