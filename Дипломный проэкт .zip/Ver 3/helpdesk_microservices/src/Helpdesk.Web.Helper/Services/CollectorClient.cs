using System.Net;
using System.Net.Http.Json;
using Helpdesk.Shared.Contracts;
using Helpdesk.Shared.Models;

namespace Helpdesk.Web.Helper.Services;

public class CollectorClient
{
    private readonly HttpClient _http;

    public CollectorClient(IHttpClientFactory factory)
    {
        _http = factory.CreateClient("collector");
    }

    public async Task<List<Ticket>> GetTicketsAsync(string? status, CancellationToken ct = default)
    {
        var url = "/api/tickets";
        if (!string.IsNullOrWhiteSpace(status))
            url += $"?status={Uri.EscapeDataString(status)}";

        var resp = await _http.GetAsync(url, ct);
        resp.EnsureSuccessStatusCode();
        return (await resp.Content.ReadFromJsonAsync<List<Ticket>>(cancellationToken: ct)) ?? new();
    }

    public async Task<Ticket?> GetTicketAsync(int id, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"/api/tickets/{id}", ct);
        if (resp.StatusCode == HttpStatusCode.NotFound) return null;
        resp.EnsureSuccessStatusCode();
        return await resp.Content.ReadFromJsonAsync<Ticket>(cancellationToken: ct);
    }

    public async Task<bool> TakeTicketAsync(int id, AssignTicketRequest req, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync($"/api/tickets/{id}/take", req, ct);
        return resp.IsSuccessStatusCode;
    }

    public async Task<(bool Ok, string? Error)> RequestCloseAsync(int id, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync($"/api/tickets/{id}/request-close", new CloseRequest { RequestedBy = "helper" }, ct);
        if (resp.IsSuccessStatusCode) return (true, null);
        var err = await resp.Content.ReadAsStringAsync(ct);
        return (false, err);
    }

    public async Task<bool> CloseTicketAsync(int id, string? reason, CancellationToken ct = default)
    {
        var url = $"/api/tickets/{id}/close";
        if (!string.IsNullOrWhiteSpace(reason))
            url += $"?reason={Uri.EscapeDataString(reason)}";
        var resp = await _http.PostAsync(url, content: null, ct);
        return resp.IsSuccessStatusCode;
    }

    public async Task<bool> DeleteTicketAsync(int id, CancellationToken ct = default)
    {
        var resp = await _http.DeleteAsync($"/api/tickets/{id}", ct);
        return resp.IsSuccessStatusCode;
    }

    public async Task<TicketMessage?> AddMessageAsync(int ticketId, AddMessageRequest req, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync($"/api/tickets/{ticketId}/messages", req, ct);
        if (!resp.IsSuccessStatusCode) return null;
        return await resp.Content.ReadFromJsonAsync<TicketMessage>(cancellationToken: ct);
    }

    public async Task<FileUploadResponse?> UploadFileAsync(Stream stream, string fileName, string contentType, CancellationToken ct = default)
    {
        using var content = new MultipartFormDataContent();
        var fileContent = new StreamContent(stream);
        fileContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(contentType);
        content.Add(fileContent, "file", fileName);

        var resp = await _http.PostAsync("/api/files", content, ct);
        if (!resp.IsSuccessStatusCode) return null;
        return await resp.Content.ReadFromJsonAsync<FileUploadResponse>(cancellationToken: ct);
    }

    // Accounts
    public async Task<Account?> LoginAsync(string login, string password, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync("/api/accounts/login", new AccountLoginRequest { Login = login, Password = password }, ct);
        if (resp.StatusCode == HttpStatusCode.Unauthorized) return null;
        resp.EnsureSuccessStatusCode();
        return await resp.Content.ReadFromJsonAsync<Account>(cancellationToken: ct);
    }

    public async Task<List<Account>> GetAccountsAsync(CancellationToken ct = default)
    {
        var resp = await _http.GetAsync("/api/accounts", ct);
        resp.EnsureSuccessStatusCode();
        return (await resp.Content.ReadFromJsonAsync<List<Account>>(cancellationToken: ct)) ?? new();
    }

    public async Task<Account?> GetAccountAsync(int id, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"/api/accounts/{id}", ct);
        if (resp.StatusCode == HttpStatusCode.NotFound) return null;
        resp.EnsureSuccessStatusCode();
        return await resp.Content.ReadFromJsonAsync<Account>(cancellationToken: ct);
    }

    public async Task<Account?> CreateAccountAsync(Account acc, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync("/api/accounts", acc, ct);
        if (!resp.IsSuccessStatusCode) return null;
        return await resp.Content.ReadFromJsonAsync<Account>(cancellationToken: ct);
    }

    public async Task<bool> UpdateAccountAsync(int id, Account acc, CancellationToken ct = default)
    {
        var resp = await _http.PutAsJsonAsync($"/api/accounts/{id}", acc, ct);
        return resp.IsSuccessStatusCode;
    }

    public async Task<bool> DeleteAccountAsync(int id, CancellationToken ct = default)
    {
        var resp = await _http.DeleteAsync($"/api/accounts/{id}", ct);
        return resp.IsSuccessStatusCode;
    }
}
