using System.Net;
using Helpdesk.Web.Helper.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Telegram.Bot;

namespace Helpdesk.Web.Helper.Controllers;

/// <summary>
/// Proxy for Telegram attachments (FileId) so helper web UI can display them.
/// </summary>
[Authorize]
public class FilesController : Controller
{
    private readonly IConfiguration _config;
    private readonly CollectorClient _collector;

    public FilesController(IConfiguration config, CollectorClient collector)
    {
        _config = config;
        _collector = collector;
    }

    [HttpGet]
    public async Task<IActionResult> Telegram(string fileId, int? ticketId = null, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(fileId))
            return NotFound();

        // Optional safety: verify fileId belongs to the ticket
        if (ticketId.HasValue)
        {
            var t = await _collector.GetTicketAsync(ticketId.Value, ct);
            if (t == null) return NotFound();

            var exists = (t.AttachmentsJson?.Contains(fileId) ?? false);
            if (!exists && t.Messages != null)
            {
                exists = t.Messages.Any(m => (m.AttachmentsJson?.Contains(fileId) ?? false));
            }

            if (!exists)
                return NotFound();
        }

        var token = _config["Telegram:BotToken"];
        if (string.IsNullOrWhiteSpace(token))
            return NotFound();

        var bot = new TelegramBotClient(token);

        Telegram.Bot.Types.File file;
        try
        {
            file = await bot.GetFileAsync(fileId, ct);
        }
        catch
        {
            return NotFound();
        }

        if (string.IsNullOrWhiteSpace(file.FilePath))
            return NotFound();

        var url = $"https://api.telegram.org/file/bot{token}/{file.FilePath}";

        try
        {
            using var http = new HttpClient();
            var resp = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);
            if (resp.StatusCode == HttpStatusCode.NotFound)
                return NotFound();
            resp.EnsureSuccessStatusCode();

            var contentType = resp.Content.Headers.ContentType?.ToString() ?? "application/octet-stream";
            var stream = await resp.Content.ReadAsStreamAsync(ct);
            return File(stream, contentType);
        }
        catch
        {
            return NotFound();
        }
    }
}
