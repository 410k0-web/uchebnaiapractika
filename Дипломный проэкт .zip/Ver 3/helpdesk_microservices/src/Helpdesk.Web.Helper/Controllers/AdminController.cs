using Helpdesk.Shared.Models;
using Helpdesk.Web.Helper.Models;
using Helpdesk.Web.Helper.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Helpdesk.Web.Helper.Controllers;

[Authorize(Roles = AccountRole.SuperAdmin)]
public class AdminController : Controller
{
    private readonly CollectorClient _collector;

    public AdminController(CollectorClient collector)
    {
        _collector = collector;
    }

    public async Task<IActionResult> Accounts(CancellationToken ct = default)
    {
        var accounts = await _collector.GetAccountsAsync(ct);
        return View(accounts);
    }

    [HttpGet]
    public IActionResult CreateAccount()
    {
        var vm = new AccountEditViewModel { Role = AccountRole.Helper };
        return View("EditAccount", vm);
    }

    [HttpPost]
    public async Task<IActionResult> CreateAccount(AccountEditViewModel vm, CancellationToken ct = default)
    {
        if (!ModelState.IsValid)
            return View("EditAccount", vm);

        if (string.IsNullOrWhiteSpace(vm.Password))
        {
            ModelState.AddModelError(nameof(vm.Password), "Пароль обязателен.");
            return View("EditAccount", vm);
        }

        var account = new Account
        {
            Login = vm.Login,
            Password = vm.Password,
            Name = vm.Name,
            LastName = vm.LastName,
            Phone = vm.Phone,
            Role = vm.Role
        };

        await _collector.CreateAccountAsync(account, ct);
        return RedirectToAction("Accounts");
    }

    [HttpGet]
    public async Task<IActionResult> EditAccount(int id, CancellationToken ct = default)
    {
        var account = await _collector.GetAccountAsync(id, ct);
        if (account == null) return NotFound();

        var vm = new AccountEditViewModel
        {
            Id = account.Id,
            Login = account.Login,
            Name = account.Name,
            LastName = account.LastName,
            Phone = account.Phone,
            Role = account.Role
        };

        return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> EditAccount(AccountEditViewModel vm, CancellationToken ct = default)
    {
        if (!ModelState.IsValid)
            return View(vm);

        if (vm.Id == null) return BadRequest();

        var account = await _collector.GetAccountAsync(vm.Id.Value, ct);
        if (account == null) return NotFound();

        account.Login = vm.Login;
        account.Name = vm.Name;
        account.LastName = vm.LastName;
        account.Phone = vm.Phone;
        account.Role = vm.Role;

        if (!string.IsNullOrWhiteSpace(vm.Password))
            account.Password = vm.Password;

        await _collector.UpdateAccountAsync(account.Id, account, ct);

        return RedirectToAction("Accounts");
    }

    [HttpPost]
    public async Task<IActionResult> DeleteAccount(int id, CancellationToken ct = default)
    {
        await _collector.DeleteAccountAsync(id, ct);
        return RedirectToAction("Accounts");
    }
}
