using System.Security.Claims;
using System.Text.Json;
using Helpdesk.Shared.Contracts;
using Helpdesk.Shared.Models;
using Helpdesk.Web.Helper.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Helpdesk.Web.Helper.Controllers;

[Authorize]
public class HomeController : Controller
{
    private readonly CollectorClient _collector;
    private readonly ILogger<HomeController> _logger;

    public HomeController(CollectorClient collector, ILogger<HomeController> logger)
    {
        _collector = collector;
        _logger = logger;
    }

    [AllowAnonymous]
    public IActionResult Error()
    {
        // ... helper/admin UI.
        return View();
    }

    public async Task<IActionResult> Index(string? status, CancellationToken ct = default)
    {
        status = string.IsNullOrWhiteSpace(status) ? "open" : status;
        var tickets = await _collector.GetTicketsAsync(status, ct);
        ViewBag.Status = status;
        return View(tickets);
    }

    public async Task<IActionResult> Ticket(int id, CancellationToken ct = default)
    {
        var ticket = await _collector.GetTicketAsync(id, ct);
        if (ticket == null) return NotFound();
        return View(ticket);
    }

    [HttpPost]
    public async Task<IActionResult> TakeTicket(int id, CancellationToken ct = default)
    {
        var helperIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!long.TryParse(helperIdClaim, out var helperId))
            helperId = 0;

        var helperName = User.FindFirst("FullName")?.Value;
        var helperUsername = User.Identity?.Name;

        var ok = await _collector.TakeTicketAsync(id, new AssignTicketRequest
        {
            HelperTelegramId = helperId,
            HelperName = helperName,
            HelperUsername = helperUsername
        }, ct);

        if (!ok)
            TempData["SendError"] = "Не удалось взять тикет (возможно уже взяли).";

        return RedirectToAction("Ticket", new { id });
    }

    [HttpPost]
    public async Task<IActionResult> RequestClose(int ticketId, CancellationToken ct = default)
    {
        var (ok, err) = await _collector.RequestCloseAsync(ticketId, ct);
        if (!ok)
            TempData["SendError"] = string.IsNullOrWhiteSpace(err) ? "Не удалось отправить запрос закрытия." : err;
        else
            TempData["SendOk"] = "Запрос на закрытие отправлен.";

        return RedirectToAction("Ticket", new { id = ticketId });
    }

    [HttpPost]
    public async Task<IActionResult> CloseTicket(int id, CancellationToken ct = default)
    {
        var ok = await _collector.CloseTicketAsync(id, "Закрыт хелпером", ct);
        TempData["SendOk"] = ok ? "Тикет закрыт." : "Не удалось закрыть тикет.";
        return RedirectToAction("Ticket", new { id });
    }

    [Authorize(Roles = AccountRole.SuperAdmin)]
    [HttpPost]
    public async Task<IActionResult> ForceClose(int id, CancellationToken ct = default)
    {
        var ok = await _collector.CloseTicketAsync(id, "Принудительно закрыт администратором", ct);
        TempData["SendOk"] = ok ? "Тикет закрыт." : "Не удалось закрыть тикет.";
        return RedirectToAction("Ticket", new { id });
    }

    [Authorize(Roles = AccountRole.SuperAdmin)]
    [HttpPost]
    public async Task<IActionResult> DeleteTicket(int id, CancellationToken ct = default)
    {
        await _collector.DeleteTicketAsync(id, ct);
        return RedirectToAction("Index");
    }

    [HttpPost]
    public async Task<IActionResult> SendHelperMessage(int ticketId, string? text, List<IFormFile>? files, CancellationToken ct = default)
    {
        var hasText = !string.IsNullOrWhiteSpace(text);
        var hasFiles = files != null && files.Any(f => f != null && f.Length > 0);

        if (!hasText && !hasFiles)
        {
            TempData["SendError"] = "Нельзя отправить пустое сообщение.";
            return RedirectToAction("Ticket", new { id = ticketId });
        }

        var attachments = new List<AttachmentItem>();

        if (hasFiles)
        {
            foreach (var f in files!)
            {
                if (f == null || f.Length <= 0) continue;

                await using var stream = f.OpenReadStream();
                var contentType = string.IsNullOrWhiteSpace(f.ContentType) ? "application/octet-stream" : f.ContentType;
                var upload = await _collector.UploadFileAsync(stream, f.FileName, contentType, ct);
                if (upload == null) continue;

                var type = "document";
                if (contentType.StartsWith("image/", StringComparison.OrdinalIgnoreCase)) type = "photo";
                else if (contentType.StartsWith("video/", StringComparison.OrdinalIgnoreCase)) type = "video";

                attachments.Add(new AttachmentItem
                {
                    Type = type,
                    Url = upload.Url,
                    FileName = f.FileName
                });
            }
        }

        var helperIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        long.TryParse(helperIdClaim, out var helperId);

        var helperUsername = User.Identity?.Name;

        var msg = await _collector.AddMessageAsync(ticketId, new AddMessageRequest
        {
            FromRole = "helper",
            FromUserId = helperId == 0 ? null : helperId,
            FromUsername = helperUsername,
            Text = hasText ? text!.Trim() : null,
            Attachments = attachments.Any() ? attachments : null,
            EnqueueToTelegramUser = true
        }, ct);

        if (msg == null)
            TempData["SendError"] = "Не удалось отправить сообщение.";
        else
            TempData["SendOk"] = "Сообщение отправлено.";

        return RedirectToAction("Ticket", new { id = ticketId });
    }
}
