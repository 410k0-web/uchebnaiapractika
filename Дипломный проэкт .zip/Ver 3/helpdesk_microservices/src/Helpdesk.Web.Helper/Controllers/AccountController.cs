using System.Security.Claims;
using Helpdesk.Shared.Models;
using Helpdesk.Web.Helper.Models;
using Helpdesk.Web.Helper.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Helpdesk.Web.Helper.Controllers;

public class AccountController : Controller
{
    private readonly CollectorClient _collector;

    public AccountController(CollectorClient collector)
    {
        _collector = collector;
    }

    [AllowAnonymous]
    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        ViewBag.ReturnUrl = returnUrl;
        return View();
    }

    [AllowAnonymous]
    [HttpPost]
    public async Task<IActionResult> Login(string username, string password, string? returnUrl = null, CancellationToken ct = default)
    {
        var account = await _collector.LoginAsync(username, password, ct);

        if (account != null)
        {
            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, account.Id.ToString()),
                new(ClaimTypes.Name, account.Login),
                new(ClaimTypes.Role, account.Role),
                new("FullName", $"{account.Name} {account.LastName}".Trim())
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            return RedirectToAction("Index", "Home");
        }

        ViewBag.ReturnUrl = returnUrl;
        ViewBag.LoginError = "Неверный логин или пароль.";
        return View();
    }

    [Authorize]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction("Login", "Account");
    }

    [Authorize]
    [HttpGet]
    public async Task<IActionResult> Profile(CancellationToken ct = default)
    {
        var idClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!int.TryParse(idClaim, out var accountId))
            return RedirectToAction("Login");

        var account = await _collector.GetAccountAsync(accountId, ct);
        if (account == null)
            return RedirectToAction("Login");

        var vm = new ProfileViewModel
        {
            Id = account.Id,
            Login = account.Login,
            Name = account.Name,
            LastName = account.LastName,
            Phone = account.Phone
        };

        return View(vm);
    }

    [Authorize]
    [HttpPost]
    public async Task<IActionResult> Profile(ProfileViewModel vm, CancellationToken ct = default)
    {
        if (!ModelState.IsValid)
            return View(vm);

        var account = await _collector.GetAccountAsync(vm.Id, ct);
        if (account == null)
            return RedirectToAction("Login");

        account.Login = vm.Login;
        account.Name = vm.Name;
        account.LastName = vm.LastName;
        account.Phone = vm.Phone;

        if (!string.IsNullOrWhiteSpace(vm.NewPassword))
        {
            if (vm.NewPassword != vm.ConfirmPassword)
            {
                ModelState.AddModelError(nameof(vm.NewPassword), "Пароль и подтверждение не совпадают.");
                return View(vm);
            }

            account.Password = vm.NewPassword;
        }

        await _collector.UpdateAccountAsync(account.Id, account, ct);

        ViewBag.ProfileSaved = true;
        return View(vm);
    }
}
