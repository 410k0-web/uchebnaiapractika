using Helpdesk.Web.Helper.Services;
using Microsoft.AspNetCore.Authentication.Cookies;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// HttpClient for Collector API
// В Development по умолчанию работаем с локальным Collector.
// Если в системе осталась переменная окружения Collector__BaseUrl=http://collector:8080,
// это ломает запуск из Visual Studio (collector не резолвится). Поэтому в Development подменяем.
var collectorBase = (builder.Configuration["Collector:BaseUrl"] ?? (builder.Environment.IsDevelopment() ? "http://localhost:7000" : "http://collector:8080"))
    .TrimEnd('/');
if (builder.Environment.IsDevelopment() && collectorBase.Contains("collector", StringComparison.OrdinalIgnoreCase))
    collectorBase = "http://localhost:7000";
builder.Services.AddHttpClient("collector", http =>
{
    http.BaseAddress = new Uri(collectorBase);
    http.Timeout = TimeSpan.FromSeconds(30);
})
.ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
{
    UseProxy = false
});

builder.Services.AddScoped<CollectorClient>();

// Cookie auth
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.LogoutPath = "/Account/Logout";
        options.AccessDeniedPath = "/Account/Login";
    });

builder.Services.AddAuthorization();

var app = builder.Build();

// Дружелюбная страница, если Collector недоступен
app.UseExceptionHandler("/Home/Error");

app.UseStaticFiles();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
