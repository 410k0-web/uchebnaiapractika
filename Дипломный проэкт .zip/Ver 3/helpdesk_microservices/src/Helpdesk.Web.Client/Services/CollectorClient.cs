using System.Net;
using System.Net.Http.Json;
using Helpdesk.Shared.Contracts;
using Helpdesk.Shared.Models;

namespace Helpdesk.Web.Client.Services;

public class CollectorClient
{
    private readonly HttpClient _http;

    public CollectorClient(IHttpClientFactory factory)
    {
        _http = factory.CreateClient("collector");
    }

    // Tickets
    public async Task<Ticket?> GetOpenTicketByIpAsync(string ip, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"/api/tickets/open/by-ip/{Uri.EscapeDataString(ip)}", ct);
        if (resp.StatusCode == HttpStatusCode.NotFound) return null;
        resp.EnsureSuccessStatusCode();
        return await resp.Content.ReadFromJsonAsync<Ticket>(cancellationToken: ct);
    }

    public async Task<List<Ticket>> GetTicketsByIpAsync(string ip, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"/api/tickets/by-ip?ip={Uri.EscapeDataString(ip)}", ct);
        resp.EnsureSuccessStatusCode();
        return (await resp.Content.ReadFromJsonAsync<List<Ticket>>(cancellationToken: ct)) ?? new();
    }

    public async Task<Ticket?> GetTicketByPhoneAsync(int id, string phone, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"/api/tickets/{id}/by-phone/{Uri.EscapeDataString(phone)}", ct);
        if (resp.StatusCode == HttpStatusCode.NotFound) return null;
        resp.EnsureSuccessStatusCode();
        return await resp.Content.ReadFromJsonAsync<Ticket>(cancellationToken: ct);
    }

    public async Task<Ticket?> CreateTicketAsync(CreateTicketRequest req, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync("/api/tickets", req, ct);
        resp.EnsureSuccessStatusCode();
        return await resp.Content.ReadFromJsonAsync<Ticket>(cancellationToken: ct);
    }

    public async Task<TicketMessage?> AddMessageAsync(int ticketId, AddMessageRequest req, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync($"/api/tickets/{ticketId}/messages", req, ct);
        if (!resp.IsSuccessStatusCode) return null;
        return await resp.Content.ReadFromJsonAsync<TicketMessage>(cancellationToken: ct);
    }

    public async Task<bool> KeepOpenAsync(int ticketId, CancellationToken ct = default)
    {
        var resp = await _http.PostAsync($"/api/tickets/{ticketId}/confirm/keep-open", content: null, ct);
        return resp.IsSuccessStatusCode;
    }

    public async Task<bool> ConfirmCloseAsync(int ticketId, CancellationToken ct = default)
    {
        var resp = await _http.PostAsync($"/api/tickets/{ticketId}/confirm/close", content: null, ct);
        return resp.IsSuccessStatusCode;
    }

    public async Task<FileUploadResponse?> UploadFileAsync(Stream stream, string fileName, string contentType, CancellationToken ct = default)
    {
        using var content = new MultipartFormDataContent();
        var fileContent = new StreamContent(stream);
        fileContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(contentType);
        content.Add(fileContent, "file", fileName);

        var resp = await _http.PostAsync("/api/files", content, ct);
        if (!resp.IsSuccessStatusCode) return null;
        return await resp.Content.ReadFromJsonAsync<FileUploadResponse>(cancellationToken: ct);
    }
}
