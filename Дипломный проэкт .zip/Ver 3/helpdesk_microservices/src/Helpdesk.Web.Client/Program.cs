using Helpdesk.Web.Client.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// В Development по умолчанию работаем с локальным Collector.
// Если в системе осталась переменная окружения Collector__BaseUrl=http://collector:8080,
// это ломает запуск из Visual Studio (collector не резолвится). Поэтому в Development подменяем.
var collectorBase = (builder.Configuration["Collector:BaseUrl"] ?? (builder.Environment.IsDevelopment() ? "http://localhost:7000" : "http://collector:8080"))
    .TrimEnd('/');
if (builder.Environment.IsDevelopment() && collectorBase.Contains("collector", StringComparison.OrdinalIgnoreCase))
    collectorBase = "http://localhost:7000";
builder.Services.AddHttpClient("collector", http =>
{
    http.BaseAddress = new Uri(collectorBase);
    http.Timeout = TimeSpan.FromSeconds(30);
})
.ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
{
    UseProxy = false
});

builder.Services.AddScoped<CollectorClient>();

var app = builder.Build();

// Показываем дружелюбную страницу, если Collector недоступен
app.UseExceptionHandler("/Client/Error");

app.UseStaticFiles();
app.UseRouting();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Client}/{action=Menu}/{id?}");

app.Run();
