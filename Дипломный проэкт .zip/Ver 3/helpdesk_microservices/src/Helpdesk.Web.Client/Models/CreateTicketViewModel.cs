using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace Helpdesk.Web.Client.Models;

public class CreateTicketViewModel
{
    [Required]
    public string FullName { get; set; } = string.Empty;

    [Required]
    public string Phone { get; set; } = string.Empty;

    public string AccountNumber { get; set; } = string.Empty;

    public string Reason { get; set; } = string.Empty;

    [Required]
    public string ProblemType { get; set; } = string.Empty;

    public string? Comment { get; set; }

    public IFormFile? PhotoFile { get; set; }
}
