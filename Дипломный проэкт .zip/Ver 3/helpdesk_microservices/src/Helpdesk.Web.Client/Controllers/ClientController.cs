using System.Text.Json;
using Helpdesk.Shared.Contracts;
using Helpdesk.Shared.Models;
using Helpdesk.Web.Client.Models;
using Helpdesk.Web.Client.Services;
using Microsoft.AspNetCore.Mvc;

namespace Helpdesk.Web.Client.Controllers;

public class ClientController : Controller
{
    private readonly CollectorClient _collector;

    public ClientController(CollectorClient collector)
    {
        _collector = collector;
    }

    [HttpGet]
    public IActionResult Error()
    {
        // Универсальная страница ошибок: чаще всего сюда попадают при недоступном Collector.
        return View();
    }

    /// <summary>
    /// Главное меню: просмотр активного тикета + создание нового.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Menu(CancellationToken ct = default)
    {
        var ip = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
        var open = await _collector.GetOpenTicketByIpAsync(ip, ct);

        ViewBag.OpenTicketId = open?.Id;
        ViewBag.OpenTicketPhone = open?.Phone;
        return View();
    }

    [HttpGet]
    public IActionResult CreateTicket()
    {
        return View(new CreateTicketViewModel());
    }

    [HttpPost]
    public async Task<IActionResult> CreateTicket(CreateTicketViewModel vm, CancellationToken ct = default)
    {
        if (!ModelState.IsValid)
            return View(vm);

        var ip = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
        var ipTag = $"[IP:{ip}]";

        // 1) С этого IP уже есть открытый тикет? -> ведём в чат
        var existingOpen = await _collector.GetOpenTicketByIpAsync(ip, ct);
        if (existingOpen != null)
            return RedirectToAction("Chat", new { id = existingOpen.Id, phone = existingOpen.Phone });

        // 2) Если прикрепили фото — заливаем в Collector и сохраняем как Photo (/uploads/xxx)
        string? photoUrl = null;
        if (vm.PhotoFile != null && vm.PhotoFile.Length > 0)
        {
            await using var stream = vm.PhotoFile.OpenReadStream();
            var contentType = string.IsNullOrWhiteSpace(vm.PhotoFile.ContentType) ? "application/octet-stream" : vm.PhotoFile.ContentType;
            var uploaded = await _collector.UploadFileAsync(stream, vm.PhotoFile.FileName, contentType, ct);
            if (uploaded != null)
                photoUrl = uploaded.Url;
        }

        var baseComment = vm.Comment ?? string.Empty;
        var storedComment = string.IsNullOrWhiteSpace(baseComment)
            ? ipTag
            : $"{ipTag}\n{baseComment}";

        var ticket = await _collector.CreateTicketAsync(new CreateTicketRequest
        {
            Source = "web",
            FullName = vm.FullName,
            Reason = vm.Reason ?? string.Empty,
            Phone = vm.Phone,
            AccountNumber = vm.AccountNumber ?? string.Empty,
            ProblemType = vm.ProblemType,
            Comment = storedComment,
            Photo = photoUrl
        }, ct);

        if (ticket == null)
        {
            TempData["ChatError"] = "Не удалось создать тикет. Попробуйте ещё раз.";
            return View(vm);
        }

        return RedirectToAction("CreateTicketSuccess", new { id = ticket.Id });
    }

    [HttpGet]
    public async Task<IActionResult> CreateTicketSuccess(int id, CancellationToken ct = default)
    {
        // На странице успеха нужно показать номер + телефон (в качестве "ключа" к чату)
        // Так как прямого эндпоинта "ticket by id" для анонима нет, берём через историю по IP и ищем.
        var ip = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
        var list = await _collector.GetTicketsByIpAsync(ip, ct);
        var ticket = list.FirstOrDefault(t => t.Id == id);
        if (ticket == null) return NotFound();

        ViewBag.TicketId = ticket.Id;
        ViewBag.Phone = ticket.Phone;
        return View();
    }

    [HttpGet]
    public async Task<IActionResult> Chat(int id, string phone, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(phone))
            return RedirectToAction("CreateTicketSuccess", new { id });

        var ticket = await _collector.GetTicketByPhoneAsync(id, phone, ct);
        if (ticket == null) return NotFound();
        return View("Chat", ticket);
    }

    [HttpPost]
    public async Task<IActionResult> SendClientMessage(int id, string phone, string? text, List<IFormFile>? files, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(phone))
            return RedirectToAction("CreateTicketSuccess", new { id });

        var hasText = !string.IsNullOrWhiteSpace(text);
        var hasFiles = files != null && files.Any(f => f != null && f.Length > 0);
        if (!hasText && !hasFiles)
        {
            TempData["ChatError"] = "Нельзя отправить пустое сообщение.";
            return RedirectToAction("Chat", new { id, phone });
        }

        var ticket = await _collector.GetTicketByPhoneAsync(id, phone, ct);
        if (ticket == null) return NotFound();

        if (ticket.Status == TicketStatus.Closed)
        {
            TempData["ChatError"] = "Тикет закрыт, отправка сообщений недоступна.";
            return RedirectToAction("Chat", new { id, phone });
        }

        var attachments = new List<AttachmentItem>();
        if (hasFiles)
        {
            foreach (var f in files!)
            {
                if (f == null || f.Length <= 0) continue;
                // в веб-клиенте разрешаем только картинки (как было)
                if (string.IsNullOrWhiteSpace(f.ContentType) || !f.ContentType.StartsWith("image/", StringComparison.OrdinalIgnoreCase))
                    continue;

                await using var stream = f.OpenReadStream();
                var uploaded = await _collector.UploadFileAsync(stream, f.FileName, f.ContentType, ct);
                if (uploaded == null) continue;

                attachments.Add(new AttachmentItem
                {
                    Type = "photo",
                    Url = uploaded.Url,
                    FileName = uploaded.OriginalFileName
                });
            }
        }

        var msg = await _collector.AddMessageAsync(id, new AddMessageRequest
        {
            FromRole = "client",
            FromUserId = 0,
            FromUsername = ticket.FullName,
            Text = hasText ? text!.Trim() : null,
            Attachments = attachments.Any() ? attachments : null,
            EnqueueToSupportChat = true,
            EnqueueToTelegramUser = false
        }, ct);

        if (msg == null)
            TempData["ChatError"] = "Не удалось отправить сообщение.";

        return RedirectToAction("Chat", new { id, phone });
    }

    /// <summary>
    /// Клиент отвечает "нужна помощь" на запрос закрытия.
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> KeepOpen(int id, string phone, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(phone))
            return RedirectToAction("CreateTicketSuccess", new { id });

        var ticket = await _collector.GetTicketByPhoneAsync(id, phone, ct);
        if (ticket == null) return NotFound();

        if (ticket.Status == TicketStatus.Closed)
        {
            TempData["ChatError"] = "Тикет уже закрыт.";
            return RedirectToAction("Chat", new { id, phone });
        }

        if (!ticket.CloseConfirmationPending)
        {
            TempData["ChatError"] = "Сейчас нет запроса на закрытие.";
            return RedirectToAction("Chat", new { id, phone });
        }

        var ok = await _collector.KeepOpenAsync(id, ct);
        if (!ok) TempData["ChatError"] = "Не удалось обновить тикет.";
        return RedirectToAction("Chat", new { id, phone });
    }

    /// <summary>
    /// Клиент подтверждает закрытие тикета.
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> ConfirmClose(int id, string phone, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(phone))
            return RedirectToAction("CreateTicketSuccess", new { id });

        var ticket = await _collector.GetTicketByPhoneAsync(id, phone, ct);
        if (ticket == null) return NotFound();

        if (ticket.Status == TicketStatus.Closed)
            return RedirectToAction("Chat", new { id, phone });

        if (!ticket.CloseConfirmationPending)
        {
            TempData["ChatError"] = "Сейчас нет запроса на закрытие.";
            return RedirectToAction("Chat", new { id, phone });
        }

        var ok = await _collector.ConfirmCloseAsync(id, ct);
        if (!ok) TempData["ChatError"] = "Не удалось закрыть тикет.";
        return RedirectToAction("Chat", new { id, phone });
    }

    /// <summary>
    /// История обращений с этого IP.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> MyTickets(CancellationToken ct = default)
    {
        var ip = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
        var tickets = await _collector.GetTicketsByIpAsync(ip, ct);
        return View(tickets);
    }
}
