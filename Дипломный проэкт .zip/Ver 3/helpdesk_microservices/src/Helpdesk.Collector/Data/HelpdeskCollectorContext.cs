using Helpdesk.Shared.Models;
using Microsoft.EntityFrameworkCore;

namespace Helpdesk.Collector.Data;

public class HelpdeskCollectorContext : DbContext
{
    public HelpdeskCollectorContext(DbContextOptions<HelpdeskCollectorContext> options) : base(options)
    {
    }

    public DbSet<Ticket> Tickets => Set<Ticket>();
    public DbSet<TicketMessage> TicketMessages => Set<TicketMessage>();
    public DbSet<Account> Accounts => Set<Account>();
    public DbSet<TelegramUserSession> TelegramSessions => Set<TelegramUserSession>();
    public DbSet<OutgoingTelegramMessage> TelegramOutbox => Set<OutgoingTelegramMessage>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Ticket>()
            .HasMany(t => t.Messages)
            .WithOne(m => m.Ticket)
            .HasForeignKey(m => m.TicketId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Ticket>()
            .Property(t => t.Status)
            .HasDefaultValue(TicketStatus.Open);

        modelBuilder.Entity<Account>()
            .HasIndex(a => a.Login)
            .IsUnique();

        modelBuilder.Entity<TelegramUserSession>()
            .HasKey(s => s.UserId);

        modelBuilder.Entity<TelegramUserSession>()
            .Property(s => s.DraftJson)
            .HasDefaultValue("{}");

        modelBuilder.Entity<OutgoingTelegramMessage>()
            .HasIndex(m => m.Status);
    }
}
