using Helpdesk.Collector.Data;
using Helpdesk.Shared.Models;
using Microsoft.EntityFrameworkCore;

namespace Helpdesk.Collector.Services;

/// <summary>
/// Ежедневная автоочистка: удаляет закрытые тикеты, закрытые более 7 дней назад.
/// </summary>
public class CleanupService : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<CleanupService> _logger;

    public CleanupService(IServiceScopeFactory scopeFactory, ILogger<CleanupService> logger)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Запускаем сразу, затем раз в сутки.
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await CleanupAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Cleanup failed");
            }

            try
            {
                await Task.Delay(TimeSpan.FromHours(24), stoppingToken);
            }
            catch
            {
                // ignore
            }
        }
    }

    private async Task CleanupAsync(CancellationToken ct)
    {
        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<HelpdeskCollectorContext>();

        var cutoff = DateTime.UtcNow.AddDays(-7);

        var oldClosed = await db.Tickets
            .Where(t => t.Status == TicketStatus.Closed && t.ClosedAt != null && t.ClosedAt < cutoff)
            .ToListAsync(ct);

        if (!oldClosed.Any())
            return;

        db.Tickets.RemoveRange(oldClosed);
        await db.SaveChangesAsync(ct);

        _logger.LogInformation("Cleanup removed {Count} tickets", oldClosed.Count);
    }
}
