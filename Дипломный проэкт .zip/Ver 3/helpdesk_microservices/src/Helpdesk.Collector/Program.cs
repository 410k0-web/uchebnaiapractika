using System.Text.Json;
using System.Text.Json.Serialization;
using Helpdesk.Collector.Data;
using Helpdesk.Shared.Contracts;
using Helpdesk.Collector.Services;
using Helpdesk.Shared.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.ConfigureHttpJsonOptions(o =>
{
    o.SerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
});

// DB
var dataDir = Path.Combine(builder.Environment.ContentRootPath, "data");
Directory.CreateDirectory(dataDir);

var conn = builder.Configuration.GetConnectionString("Default");
if (string.IsNullOrWhiteSpace(conn))
{
    conn = $"Data Source={Path.Combine(dataDir, "helpdesk.db")}";
}

builder.Services.AddDbContext<HelpdeskCollectorContext>(opt =>
{
    opt.UseSqlite(conn);
});

builder.Services.AddHostedService<CleanupService>();

var app = builder.Build();

// Ensure folders exist
var uploadsDir = builder.Configuration["Uploads:Path"];
if (string.IsNullOrWhiteSpace(uploadsDir))
    uploadsDir = Path.Combine(dataDir, "uploads");
Directory.CreateDirectory(uploadsDir);

// DB init + seed
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<HelpdeskCollectorContext>();
    db.Database.EnsureCreated();

    // Seed: admin from config (в старом проекте это было в appsettings)
    var adminUser = builder.Configuration["Admin:Username"] ?? "admin";
    var adminPass = builder.Configuration["Admin:Password"] ?? "admin";

    if (!db.Accounts.Any())
    {
        db.Accounts.Add(new Account
        {
            Login = adminUser,
            Password = adminPass,
            Role = AccountRole.SuperAdmin,
            Name = "Super",
            LastName = "Admin"
        });
        db.SaveChanges();
    }
}

app.UseSwagger();
app.UseSwaggerUI();

// удобство: переход на Swagger по корню
app.MapGet("/", () => Results.Redirect("/swagger"));

// Static uploads
app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(uploadsDir),
    RequestPath = "/uploads"
});

app.MapGet("/api/health", () => Results.Ok(new { ok = true, service = "collector" }));

// ---------------------- FILES ----------------------
app.MapPost("/api/files", async (HttpRequest request) =>
{
    if (!request.HasFormContentType)
        return Results.BadRequest("multipart/form-data ожидается");

    var form = await request.ReadFormAsync();
    var file = form.Files.FirstOrDefault();
    if (file == null || file.Length == 0)
        return Results.BadRequest("file отсутствует");

    var ext = Path.GetExtension(file.FileName);
    if (string.IsNullOrWhiteSpace(ext))
        ext = ".bin";

    var stored = $"{Guid.NewGuid():N}{ext}";
    var fullPath = Path.Combine(uploadsDir!, stored);

    await using (var fs = File.Create(fullPath))
    {
        await file.CopyToAsync(fs);
    }

    var resp = new FileUploadResponse
    {
        Url = $"/uploads/{stored}",
        StoredFileName = stored,
        OriginalFileName = file.FileName,
        ContentType = file.ContentType
    };

    return Results.Ok(resp);
});

// ---------------------- TICKETS ----------------------
var tickets = app.MapGroup("/api/tickets");

// List
tickets.MapGet("", async (string? status, HelpdeskCollectorContext db) =>
{
    var q = db.Tickets.AsQueryable();
    if (status == "open") q = q.Where(t => t.Status == TicketStatus.Open);
    else if (status == "closed") q = q.Where(t => t.Status == TicketStatus.Closed);

    var list = await q.OrderByDescending(t => t.CreatedAt).ToListAsync();
    return Results.Ok(list);
});

// Details
tickets.MapGet("/{id:int}", async (int id, HelpdeskCollectorContext db) =>
{
    var ticket = await db.Tickets
        .Include(t => t.Messages)
        .FirstOrDefaultAsync(t => t.Id == id);

    if (ticket == null) return Results.NotFound();
    ticket.Messages = ticket.Messages.OrderBy(m => m.CreatedAt).ToList();
    return Results.Ok(ticket);
});

// Telegram user's open ticket
tickets.MapGet("/open/by-telegram/{userId:long}", async (long userId, HelpdeskCollectorContext db) =>
{
    var t = await db.Tickets
        .Where(x => x.UserId == userId && x.Status == TicketStatus.Open)
        .OrderByDescending(x => x.CreatedAt)
        .FirstOrDefaultAsync();

    return t == null ? Results.NotFound() : Results.Ok(t);
});

// Telegram user's last tickets
tickets.MapGet("/by-telegram/{userId:long}", async (long userId, int take, HelpdeskCollectorContext db) =>
{
    take = take <= 0 || take > 50 ? 10 : take;
    var list = await db.Tickets
        .Where(x => x.UserId == userId)
        .OrderByDescending(x => x.CreatedAt)
        .Take(take)
        .ToListAsync();
    return Results.Ok(list);
});

// Web client: open ticket by IP-tag
tickets.MapGet("/open/by-ip", async (string ip, HelpdeskCollectorContext db) =>
{
    var ipTag = $"[IP:{ip}]";
    var t = await db.Tickets
        .Where(x => x.UserId == 0 && x.Status == TicketStatus.Open && x.Comment.Contains(ipTag))
        .OrderByDescending(x => x.CreatedAt)
        .FirstOrDefaultAsync();

    return t == null ? Results.NotFound() : Results.Ok(t);
});

// Web client: open ticket by IP-tag (path variant for compatibility)
tickets.MapGet("/open/by-ip/{ip}", async (string ip, HelpdeskCollectorContext db) =>
{
    var ipTag = $"[IP:{ip}]";
    var t = await db.Tickets
        .Where(x => x.UserId == 0 && x.Status == TicketStatus.Open && x.Comment.Contains(ipTag))
        .OrderByDescending(x => x.CreatedAt)
        .FirstOrDefaultAsync();

    return t == null ? Results.NotFound() : Results.Ok(t);
});

// Web client: list tickets by IP-tag
tickets.MapGet("/by-ip", async (string ip, HelpdeskCollectorContext db) =>
{
    var ipTag = $"[IP:{ip}]";
    var list = await db.Tickets
        .Where(x => x.UserId == 0 && x.Comment.Contains(ipTag))
        .OrderByDescending(x => x.CreatedAt)
        .ToListAsync();
    return Results.Ok(list);
});

// Web client: ticket by id+phone (simple protection)
tickets.MapGet("/{id:int}/by-phone/{phone}", async (int id, string phone, HelpdeskCollectorContext db) =>
{
    var ticket = await db.Tickets
        .Include(t => t.Messages)
        .FirstOrDefaultAsync(t => t.Id == id && t.Phone == phone);

    if (ticket == null) return Results.NotFound();
    ticket.Messages = ticket.Messages.OrderBy(m => m.CreatedAt).ToList();
    return Results.Ok(ticket);
});

// Create ticket
 tickets.MapPost("", async (CreateTicketRequest req, HelpdeskCollectorContext db, IConfiguration cfg) =>
{
    var ticket = new Ticket
    {
        UserId = req.Source == "telegram" ? req.TelegramUserId : 0,
        Username = req.Source == "telegram" ? req.TelegramUsername : null,
        FullName = req.Source == "telegram"
            ? req.TelegramFullName
            : (!string.IsNullOrWhiteSpace(req.FullName) ? req.FullName : req.TelegramFullName),
        Reason = req.Reason,
        Phone = req.Phone,
        AccountNumber = req.AccountNumber,
        ProblemType = req.ProblemType,
        Comment = req.Comment,
        Photo = req.Photo,
        AttachmentsJson = req.Attachments != null && req.Attachments.Any()
            ? JsonSerializer.Serialize(req.Attachments)
            : null,
        Status = TicketStatus.Open,
        CreatedAt = DateTime.UtcNow
    };

    db.Tickets.Add(ticket);
    db.TicketMessages.Add(new TicketMessage
    {
        Ticket = ticket,
        FromRole = "system",
        FromUserId = req.Source == "telegram" ? req.TelegramUserId : 0,
        FromUsername = req.Source == "telegram" ? req.TelegramUsername : null,
        Text = req.Source == "telegram" ? "Тикет создан пользователем (Telegram)." : "Тикет создан пользователем (WEB).",
        CreatedAt = DateTime.UtcNow
    });

    await db.SaveChangesAsync();

    // Notify Support chat via outbox, if configured
    var supportChatId = cfg.GetValue<long>("Telegram:SupportChatId");
    if (supportChatId != 0)
    {
        var text =
            req.Source == "telegram"
                ? $"🆕 Новый тикет #{ticket.Id} (Telegram)\n\n" +
                  $"👤 {ticket.FullName} (@{ticket.Username})\n" +
                  $"Телефон: {ticket.Phone}\n" +
                  $"Лицевой счёт: {ticket.AccountNumber}\n" +
                  $"Тип: {ticket.ProblemType}\n" +
                  $"Комментарий: {ticket.Comment}"
                : $"🆕 Новый тикет #{ticket.Id} (сайт)\n\n" +
                  $"👤 {ticket.FullName}\n" +
                  $"Телефон: {ticket.Phone}\n" +
                  $"Лицевой счёт: {ticket.AccountNumber}\n" +
                  $"Тип: {ticket.ProblemType}\n" +
                  $"Комментарий: {ticket.Comment}";

        db.TelegramOutbox.Add(new OutgoingTelegramMessage
        {
            ChatId = supportChatId,
            TicketId = ticket.Id,
            Type = "new_ticket",
            Text = text,
            // Вложения тикета (если есть) — отправим отдельными сообщениями ботом.
            AttachmentsJson = ticket.AttachmentsJson,
            Status = OutgoingMessageStatus.Pending,
            CreatedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();
    }

    return Results.Ok(ticket);
});

// Add message
 tickets.MapPost("/{id:int}/messages", async (int id, AddMessageRequest req, HelpdeskCollectorContext db, IConfiguration cfg) =>
{
    var ticket = await db.Tickets.FirstOrDefaultAsync(t => t.Id == id);
    if (ticket == null) return Results.NotFound();

    var msg = new TicketMessage
    {
        TicketId = id,
        FromRole = req.FromRole,
        FromUserId = req.FromUserId,
        FromUsername = req.FromUsername,
        Text = string.IsNullOrWhiteSpace(req.Text) ? null : req.Text.Trim(),
        AttachmentsJson = req.Attachments != null && req.Attachments.Any()
            ? JsonSerializer.Serialize(req.Attachments)
            : null,
        CreatedAt = DateTime.UtcNow
    };

    db.TicketMessages.Add(msg);

    // Auto take ticket by helper message
    if (req.FromRole == "helper" && ticket.HelperId == null && req.FromUserId.HasValue)
    {
        ticket.HelperId = req.FromUserId.Value;
        ticket.HelperName = req.FromUsername;
        ticket.WorkStartedAt ??= DateTime.UtcNow;
    }

    await db.SaveChangesAsync();

    // Outbox to telegram user
    if (req.EnqueueToTelegramUser && ticket.UserId != 0)
    {
        db.TelegramOutbox.Add(new OutgoingTelegramMessage
        {
            ChatId = ticket.UserId,
            TicketId = ticket.Id,
            Type = "text",
            Text = msg.Text,
            AttachmentsJson = msg.AttachmentsJson,
            CreatedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();
    }

    // Outbox to support chat
    if (req.EnqueueToSupportChat)
    {
        var supportChatId = cfg.GetValue<long>("Telegram:SupportChatId");
        if (supportChatId != 0)
        {
            var notifyText = $"💬 Новое сообщение по тикету #{ticket.Id}\n" +
                             $"От: {req.FromRole}\n" +
                             (string.IsNullOrWhiteSpace(req.Text) ? "" : $"Текст: {req.Text}");

            db.TelegramOutbox.Add(new OutgoingTelegramMessage
            {
                ChatId = supportChatId,
                TicketId = ticket.Id,
                Type = "text",
                Text = notifyText,
                CreatedAt = DateTime.UtcNow
            });
            await db.SaveChangesAsync();
        }
    }

    return Results.Ok(msg);
});

// Take ticket
 tickets.MapPost("/{id:int}/take", async (int id, AssignTicketRequest req, HelpdeskCollectorContext db) =>
{
    var ticket = await db.Tickets.FirstOrDefaultAsync(t => t.Id == id);
    if (ticket == null) return Results.NotFound();

    if (ticket.HelperId.HasValue)
        return Results.Conflict("already taken");

    ticket.HelperId = req.HelperTelegramId;
    ticket.HelperName = req.HelperName ?? req.HelperUsername;
    ticket.WorkStartedAt ??= DateTime.UtcNow;

    db.TicketMessages.Add(new TicketMessage
    {
        TicketId = ticket.Id,
        FromRole = "system",
        Text = $"Тикет взят в работу: {ticket.HelperName}."
    });

    await db.SaveChangesAsync();

    if (ticket.UserId != 0)
    {
        db.TelegramOutbox.Add(new OutgoingTelegramMessage
        {
            ChatId = ticket.UserId,
            TicketId = ticket.Id,
            Type = "text",
            Text = $"Ваш тикет #{ticket.Id} взят в работу.",
            Status = OutgoingMessageStatus.Pending,
            CreatedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();
    }

    return Results.Ok(ticket);
});

// Request close confirmation
 tickets.MapPost("/{id:int}/request-close", async (int id, CloseRequest req, HelpdeskCollectorContext db, IConfiguration cfg) =>
{
    var ticket = await db.Tickets.FirstOrDefaultAsync(t => t.Id == id);
    if (ticket == null) return Results.NotFound();

    if (ticket.Status != TicketStatus.Open)
        return Results.Conflict("ticket closed");

    var now = DateTime.UtcNow;
    if (ticket.LastCloseRequestAt.HasValue && ticket.LastCloseRequestAt.Value.AddMinutes(5) > now)
        return Results.Conflict("cooldown");

    ticket.LastCloseRequestAt = now;
    ticket.CloseConfirmationPending = true;
    ticket.CloseConfirmationRequestedAt = now;

    db.TicketMessages.Add(new TicketMessage
    {
        TicketId = ticket.Id,
        FromRole = "system",
        Text = "Отправлен запрос на подтверждение закрытия клиенту.",
        CreatedAt = now
    });

    await db.SaveChangesAsync();

    if (ticket.UserId != 0)
    {
        db.TelegramOutbox.Add(new OutgoingTelegramMessage
        {
            ChatId = ticket.UserId,
            TicketId = ticket.Id,
            Type = "close_request",
            Text = $"👋 Нуждаетесь ли в помощи дальше по тикету #{ticket.Id}?",
            PayloadJson = JsonSerializer.Serialize(new { ticketId = ticket.Id }),
            CreatedAt = now
        });
        await db.SaveChangesAsync();
    }

    // notify support
    var supportChatId = cfg.GetValue<long>("Telegram:SupportChatId");
    if (supportChatId != 0)
    {
        db.TelegramOutbox.Add(new OutgoingTelegramMessage
        {
            ChatId = supportChatId,
            TicketId = ticket.Id,
            Type = "text",
            Text = $"ℹ️ Запрошено подтверждение закрытия по тикету #{ticket.Id}.",
            CreatedAt = now
        });
        await db.SaveChangesAsync();
    }

    return Results.Ok(ticket);
});

// Confirm keep open
 tickets.MapPost("/{id:int}/confirm/keep-open", async (int id, HelpdeskCollectorContext db, IConfiguration cfg) =>
{
    var ticket = await db.Tickets.FirstOrDefaultAsync(t => t.Id == id);
    if (ticket == null) return Results.NotFound();

    if (ticket.Status != TicketStatus.Open)
        return Results.Conflict("ticket closed");

    if (!ticket.CloseConfirmationPending)
        return Results.Conflict("no pending request");

    ticket.CloseConfirmationPending = false;

    db.TicketMessages.Add(new TicketMessage
    {
        TicketId = id,
        FromRole = "system",
        Text = "Клиент ответил: нужна помощь. Тикет остаётся открытым.",
        CreatedAt = DateTime.UtcNow
    });

    await db.SaveChangesAsync();

    // notify user
    if (ticket.UserId != 0)
    {
        db.TelegramOutbox.Add(new OutgoingTelegramMessage
        {
            ChatId = ticket.UserId,
            TicketId = ticket.Id,
            Type = "text",
            Text = $"👍 Понял! Тикет #{ticket.Id} остаётся открытым. Напишите, что ещё нужно — я передам специалисту.",
            CreatedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();
    }

    // notify support
    var supportChatId = cfg.GetValue<long>("Telegram:SupportChatId");
    if (supportChatId != 0)
    {
        db.TelegramOutbox.Add(new OutgoingTelegramMessage
        {
            ChatId = supportChatId,
            TicketId = ticket.Id,
            Type = "text",
            Text = $"ℹ️ Клиент подтвердил, что помощь нужна. Тикет #{ticket.Id} остаётся открытым.",
            CreatedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();
    }

    return Results.Ok(ticket);
});

// Confirm close
 tickets.MapPost("/{id:int}/confirm/close", async (int id, HelpdeskCollectorContext db, IConfiguration cfg) =>
{
    var ticket = await db.Tickets.FirstOrDefaultAsync(t => t.Id == id);
    if (ticket == null) return Results.NotFound();

    if (ticket.Status != TicketStatus.Open)
        return Results.Conflict("ticket closed");

    if (!ticket.CloseConfirmationPending)
        return Results.Conflict("no pending request");

    ticket.CloseConfirmationPending = false;
    ticket.Status = TicketStatus.Closed;
    ticket.ClosedAt = DateTime.UtcNow;

    db.TicketMessages.Add(new TicketMessage
    {
        TicketId = id,
        FromRole = "system",
        Text = "Клиент подтвердил закрытие. Тикет закрыт.",
        CreatedAt = DateTime.UtcNow
    });

    await db.SaveChangesAsync();

    if (ticket.UserId != 0)
    {
        db.TelegramOutbox.Add(new OutgoingTelegramMessage
        {
            ChatId = ticket.UserId,
            TicketId = ticket.Id,
            Type = "text",
            Text = $"✅ Ваш тикет #{ticket.Id} закрыт. Если проблема повторится — создайте новый тикет.",
            CreatedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();
    }

    var supportChatId = cfg.GetValue<long>("Telegram:SupportChatId");
    if (supportChatId != 0)
    {
        db.TelegramOutbox.Add(new OutgoingTelegramMessage
        {
            ChatId = supportChatId,
            TicketId = ticket.Id,
            Type = "text",
            Text = $"✅ Клиент подтвердил закрытие тикета #{ticket.Id}.",
            CreatedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();
    }

    return Results.Ok(ticket);
});

// Close by helper/admin
 tickets.MapPost("/{id:int}/close", async (int id, string? reason, HelpdeskCollectorContext db, IConfiguration cfg) =>
{
    var ticket = await db.Tickets.FirstOrDefaultAsync(t => t.Id == id);
    if (ticket == null) return Results.NotFound();

    if (ticket.Status == TicketStatus.Closed)
        return Results.Ok(ticket);

    ticket.Status = TicketStatus.Closed;
    ticket.ClosedAt = DateTime.UtcNow;
    ticket.CloseConfirmationPending = false;

    db.TicketMessages.Add(new TicketMessage
    {
        TicketId = id,
        FromRole = "system",
        Text = string.IsNullOrWhiteSpace(reason) ? "Тикет закрыт." : $"Тикет закрыт: {reason}" ,
        CreatedAt = DateTime.UtcNow
    });

    await db.SaveChangesAsync();

    if (ticket.UserId != 0)
    {
        db.TelegramOutbox.Add(new OutgoingTelegramMessage
        {
            ChatId = ticket.UserId,
            TicketId = ticket.Id,
            Type = "text",
            Text = $"✅ Тикет #{ticket.Id} закрыт.",
            CreatedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();
    }

    return Results.Ok(ticket);
});

// Delete
 tickets.MapDelete("/{id:int}", async (int id, HelpdeskCollectorContext db) =>
{
    var ticket = await db.Tickets.Include(t => t.Messages).FirstOrDefaultAsync(t => t.Id == id);
    if (ticket == null) return Results.NotFound();
    db.Tickets.Remove(ticket);
    await db.SaveChangesAsync();
    return Results.Ok();
});

// ---------------------- ACCOUNTS ----------------------
var accounts = app.MapGroup("/api/accounts");

accounts.MapGet("", async (HelpdeskCollectorContext db) => Results.Ok(await db.Accounts.OrderBy(a => a.Id).ToListAsync()));
accounts.MapGet("/{id:int}", async (int id, HelpdeskCollectorContext db) =>
{
    var acc = await db.Accounts.FindAsync(id);
    return acc == null ? Results.NotFound() : Results.Ok(acc);
});

accounts.MapPost("", async (Account acc, HelpdeskCollectorContext db) =>
{
    db.Accounts.Add(acc);
    await db.SaveChangesAsync();
    return Results.Ok(acc);
});

accounts.MapPut("/{id:int}", async (int id, Account updated, HelpdeskCollectorContext db) =>
{
    var acc = await db.Accounts.FindAsync(id);
    if (acc == null) return Results.NotFound();

    acc.Login = updated.Login;
    acc.Password = updated.Password;
    acc.Name = updated.Name;
    acc.LastName = updated.LastName;
    acc.Phone = updated.Phone;
    acc.Role = updated.Role;

    await db.SaveChangesAsync();
    return Results.Ok(acc);
});

accounts.MapDelete("/{id:int}", async (int id, HelpdeskCollectorContext db) =>
{
    var acc = await db.Accounts.FindAsync(id);
    if (acc == null) return Results.NotFound();
    db.Accounts.Remove(acc);
    await db.SaveChangesAsync();
    return Results.Ok();
});

accounts.MapPost("/login", async (AccountLoginRequest req, HelpdeskCollectorContext db) =>
{
    var acc = await db.Accounts.FirstOrDefaultAsync(a => a.Login == req.Login && a.Password == req.Password);
    return acc == null ? Results.Unauthorized() : Results.Ok(acc);
});

// ---------------------- TELEGRAM SESSION ----------------------
var sessions = app.MapGroup("/api/telegram/sessions");

sessions.MapGet("/{userId:long}", async (long userId, HelpdeskCollectorContext db) =>
{
    var s = await db.TelegramSessions.FindAsync(userId);
    return s == null ? Results.NotFound() : Results.Ok(s);
});

sessions.MapPut("/{userId:long}", async (long userId, TelegramUserSession session, HelpdeskCollectorContext db) =>
{
    session.UserId = userId;
    session.UpdatedAt = DateTime.UtcNow;

    var existing = await db.TelegramSessions.FindAsync(userId);
    if (existing == null)
        db.TelegramSessions.Add(session);
    else
    {
        existing.Username = session.Username;
        existing.Step = session.Step;
        existing.DraftJson = session.DraftJson;
        existing.UpdatedAt = session.UpdatedAt;
    }

    await db.SaveChangesAsync();
    return Results.Ok(session);
});

sessions.MapDelete("/{userId:long}", async (long userId, HelpdeskCollectorContext db) =>
{
    var s = await db.TelegramSessions.FindAsync(userId);
    if (s == null) return Results.NotFound();
    db.TelegramSessions.Remove(s);
    await db.SaveChangesAsync();
    return Results.Ok();
});

// ---------------------- TELEGRAM OUTBOX ----------------------
var outbox = app.MapGroup("/api/telegram/outbox");

outbox.MapGet("", async (int? limit, HelpdeskCollectorContext db) =>
{
    var take = limit is null or <= 0 or > 100 ? 20 : limit.Value;
    var now = DateTime.UtcNow;

    var items = await db.TelegramOutbox
        .Where(m => m.Status == OutgoingMessageStatus.Pending && (m.NextAttemptAt == null || m.NextAttemptAt <= now))
        .OrderBy(m => m.Id)
        .Take(take)
        .ToListAsync();

    return Results.Ok(items);
});

outbox.MapPost("/{id:long}/ack", async (long id, HelpdeskCollectorContext db) =>
{
    var msg = await db.TelegramOutbox.FindAsync(id);
    if (msg == null) return Results.NotFound();

    msg.Status = OutgoingMessageStatus.Sent;
    msg.SentAt = DateTime.UtcNow;
    msg.LastError = null;
    msg.NextAttemptAt = null;

    await db.SaveChangesAsync();
    return Results.Ok();
});

outbox.MapPost("/{id:long}/fail", async (long id, string? error, HelpdeskCollectorContext db) =>
{
    var msg = await db.TelegramOutbox.FindAsync(id);
    if (msg == null) return Results.NotFound();

    msg.Attempts += 1;
    msg.LastError = error;

    // simple backoff
    var delay = Math.Min(300, 10 * msg.Attempts);
    msg.NextAttemptAt = DateTime.UtcNow.AddSeconds(delay);

    if (msg.Attempts >= 20)
        msg.Status = OutgoingMessageStatus.Failed;

    await db.SaveChangesAsync();
    return Results.Ok();
});

app.Run();
