using Helpdesk.Bot.Telegram;
using Helpdesk.Bot.Telegram.Bot;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var host = Host.CreateDefaultBuilder(args)
    .ConfigureServices((ctx, services) =>
    {
        // Local dev defaults to localhost; docker-compose overrides via env Collector__BaseUrl.
        // Важно: у некоторых пользователей в системе может остаться env Collector__BaseUrl=http://collector:8080,
        // что ломает запуск из Visual Studio (collector не резолвится). Поэтому в Development принудительно
        // подменяем "collector" -> localhost.
        var baseUrl = (ctx.Configuration["Collector:BaseUrl"] ?? "http://localhost:7000").TrimEnd('/');
        if (ctx.HostingEnvironment.IsDevelopment() && baseUrl.Contains("collector", StringComparison.OrdinalIgnoreCase))
            baseUrl = "http://localhost:7000";

        services.AddHttpClient<CollectorApiClient>(http =>
            {
                http.BaseAddress = new Uri(baseUrl);
                http.Timeout = TimeSpan.FromSeconds(30);
            })
            // Чтобы на Windows системный прокси не подменял ответ на 502 при недоступном хосте
            .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
            {
                UseProxy = false
            });

        services.AddHostedService<BotService>();
    })
    .Build();

await host.RunAsync();
