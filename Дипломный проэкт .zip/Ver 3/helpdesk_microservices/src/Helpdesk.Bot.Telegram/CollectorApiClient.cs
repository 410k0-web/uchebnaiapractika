using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Helpdesk.Shared.Contracts;
using Helpdesk.Shared.Models;

namespace Helpdesk.Bot.Telegram;

public class CollectorApiClient
{
    private readonly HttpClient _http;

    public CollectorApiClient(HttpClient http)
    {
        _http = http;
    }

    /// <summary>
    /// Uploads a file to Collector (/api/files). Returns a URL like /uploads/{name}.
    /// </summary>
    public async Task<FileUploadResponse> UploadFileAsync(Stream content, string fileName, string contentType, CancellationToken ct)
    {
        using var form = new MultipartFormDataContent();
        var sc = new StreamContent(content);
        sc.Headers.ContentType = new MediaTypeHeaderValue(string.IsNullOrWhiteSpace(contentType) ? "application/octet-stream" : contentType);
        form.Add(sc, "file", string.IsNullOrWhiteSpace(fileName) ? "file.bin" : fileName);

        var resp = await _http.PostAsync("/api/files", form, ct);
        resp.EnsureSuccessStatusCode();

        var parsed = await resp.Content.ReadFromJsonAsync<FileUploadResponse>(cancellationToken: ct);
        return parsed ?? new FileUploadResponse { Url = null };
    }

    public async Task<Ticket?> GetOpenTicketByTelegramAsync(long userId, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"/api/tickets/open/by-telegram/{userId}", ct);
        if (resp.StatusCode == HttpStatusCode.NotFound) return null;
        resp.EnsureSuccessStatusCode();
        return await resp.Content.ReadFromJsonAsync<Ticket>(cancellationToken: ct);
    }

    public async Task<List<Ticket>> GetTicketsByTelegramAsync(long userId, int take = 10, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"/api/tickets/by-telegram/{userId}?take={take}", ct);
        resp.EnsureSuccessStatusCode();
        return (await resp.Content.ReadFromJsonAsync<List<Ticket>>(cancellationToken: ct)) ?? new();
    }

    public async Task<Ticket> CreateTicketAsync(CreateTicketRequest req, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync("/api/tickets", req, ct);
        resp.EnsureSuccessStatusCode();
        return (await resp.Content.ReadFromJsonAsync<Ticket>(cancellationToken: ct))!;
    }

    
    public async Task<Ticket?> GetTicketAsync(int ticketId, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"/api/tickets/{ticketId}", ct);
        if (resp.StatusCode == HttpStatusCode.NotFound) return null;
        resp.EnsureSuccessStatusCode();
        return await resp.Content.ReadFromJsonAsync<Ticket>(cancellationToken: ct);
    }

    public async Task<TicketMessage> AddMessageAsync(int ticketId, AddMessageRequest req, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync($"/api/tickets/{ticketId}/messages", req, ct);
        resp.EnsureSuccessStatusCode();
        return (await resp.Content.ReadFromJsonAsync<TicketMessage>(cancellationToken: ct))!;
    }

    public async Task<bool> CloseTicketAsync(int ticketId, string? reason = null, CancellationToken ct = default)
    {
        var url = $"/api/tickets/{ticketId}/close";
        if (!string.IsNullOrWhiteSpace(reason))
            url += $"?reason={Uri.EscapeDataString(reason)}";

        var resp = await _http.PostAsync(url, content: null, ct);
        return resp.IsSuccessStatusCode;
    }

    public async Task<(bool Ok, string? Error)> RequestCloseAsync(int ticketId, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync($"/api/tickets/{ticketId}/request-close", new CloseRequest { RequestedBy = "helper" }, ct);
        if (resp.IsSuccessStatusCode) return (true, null);
        var body = await resp.Content.ReadAsStringAsync(ct);
        return (false, body);
    }

    public async Task<bool> ConfirmKeepOpenAsync(int ticketId, CancellationToken ct = default)
    {
        var resp = await _http.PostAsync($"/api/tickets/{ticketId}/confirm/keep-open", content: null, ct);
        return resp.IsSuccessStatusCode;
    }

    public async Task<bool> ConfirmCloseAsync(int ticketId, CancellationToken ct = default)
    {
        var resp = await _http.PostAsync($"/api/tickets/{ticketId}/confirm/close", content: null, ct);
        return resp.IsSuccessStatusCode;
    }

    public async Task<bool> TakeTicketAsync(int ticketId, AssignTicketRequest req, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync($"/api/tickets/{ticketId}/take", req, ct);
        return resp.IsSuccessStatusCode;
    }

    // Telegram session
    public async Task<TelegramUserSession?> GetSessionAsync(long userId, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"/api/telegram/sessions/{userId}", ct);
        if (resp.StatusCode == HttpStatusCode.NotFound) return null;
        resp.EnsureSuccessStatusCode();
        return await resp.Content.ReadFromJsonAsync<TelegramUserSession>(cancellationToken: ct);
    }

    public async Task SaveSessionAsync(TelegramUserSession session, CancellationToken ct = default)
    {
        var resp = await _http.PutAsJsonAsync($"/api/telegram/sessions/{session.UserId}", session, ct);
        resp.EnsureSuccessStatusCode();
    }

    public async Task DeleteSessionAsync(long userId, CancellationToken ct = default)
    {
        var resp = await _http.DeleteAsync($"/api/telegram/sessions/{userId}", ct);
        // ignore errors
    }

    // Outbox
    public async Task<List<OutgoingTelegramMessage>> GetOutboxAsync(int limit = 20, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"/api/telegram/outbox?limit={limit}", ct);
        resp.EnsureSuccessStatusCode();
        return (await resp.Content.ReadFromJsonAsync<List<OutgoingTelegramMessage>>(cancellationToken: ct)) ?? new();
    }

    public async Task AckOutboxAsync(long id, CancellationToken ct = default)
    {
        var resp = await _http.PostAsync($"/api/telegram/outbox/{id}/ack", content: null, ct);
        // ignore
    }

    public async Task FailOutboxAsync(long id, string? error, CancellationToken ct = default)
    {
        var url = $"/api/telegram/outbox/{id}/fail";
        if (!string.IsNullOrWhiteSpace(error))
            url += $"?error={Uri.EscapeDataString(error)}";

        var resp = await _http.PostAsync(url, content: null, ct);
        // ignore
    }
}
