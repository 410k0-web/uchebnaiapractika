using System.Text.Json;
using Helpdesk.Shared.Contracts;
using Helpdesk.Shared.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

namespace Helpdesk.Bot.Telegram.Bot;

public class BotService : BackgroundService
{
    private readonly ILogger<BotService> _logger;
    private readonly CollectorApiClient _collector;
    private readonly ITelegramBotClient _bot;
    private readonly IConfiguration _cfg;
    private readonly IHostApplicationLifetime _lifetime;

    private readonly string _token;

    private readonly long _supportChatId;
    private readonly HashSet<string> _helperUsernames;

    public BotService(ILogger<BotService> logger, CollectorApiClient collector, IConfiguration cfg, IHostApplicationLifetime lifetime)
    {
        _logger = logger;
        _collector = collector;
        _cfg = cfg;
        _lifetime = lifetime;

        _token = cfg["Telegram:BotToken"] ?? string.Empty;
        _supportChatId = cfg.GetValue<long>("Telegram:SupportChatId");

        // Note: If token is empty/invalid, we will stop the app in ExecuteAsync with a clear log.
        _bot = new TelegramBotClient(_token);

        _helperUsernames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var helpers = (cfg["Telegram:HelperUsernames"] ?? string.Empty)
            .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        foreach (var h in helpers) _helperUsernames.Add(h.TrimStart('@'));
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Если токен не задан (или оставлен плейсхолдером) — не падаем и не завершаем весь хост.
        // Просто держим процесс живым, чтобы docker-compose/VS не считали сервис "упавшим".
        if (string.IsNullOrWhiteSpace(_token) || _token.Equals("PUT_YOUR_BOT_TOKEN_HERE", StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogWarning(
                "Telegram bot token is not configured. Set Telegram:BotToken (or env Telegram__BotToken) and restart. Bot will stay idle.");
            try { await Task.Delay(Timeout.Infinite, stoppingToken); } catch { /* ignore */ }
            return;
        }

        // Validate token early (Telegram returns 404 Not Found for invalid token).
        try
        {
            var me = await _bot.GetMeAsync(stoppingToken);
            _logger.LogInformation("Telegram bot authorized as @{Username} (id={Id}).", me.Username, me.Id);
        }
        catch (ApiRequestException ex)
        {
            _logger.LogError(
                "Telegram bot cannot authorize (likely invalid token). Telegram API error: {Code} {Message}. Bot will stay idle.",
                ex.ErrorCode, ex.Message);
            try { await Task.Delay(Timeout.Infinite, stoppingToken); } catch { /* ignore */ }
            return;
        }

        var receiverOptions = new ReceiverOptions
        {
            AllowedUpdates = Array.Empty<UpdateType>()
        };

        // 1) Poll Telegram updates
        var pollTask = Task.Run(async () =>
        {
            _bot.StartReceiving(HandleUpdateAsync, HandleErrorAsync, receiverOptions, cancellationToken: stoppingToken);
            // Keep task alive
            while (!stoppingToken.IsCancellationRequested)
                await Task.Delay(1000, stoppingToken);
        }, stoppingToken);

        // 2) Outbox loop
        var outboxTask = Task.Run(() => RunOutboxLoop(stoppingToken), stoppingToken);

        await Task.WhenAll(pollTask, outboxTask);
    }

    private async Task RunOutboxLoop(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                var items = await _collector.GetOutboxAsync(limit: 25, ct);
                foreach (var item in items)
                {
                    try
                    {
                        await SendOutboxItemAsync(item, ct);
                        await _collector.AckOutboxAsync(item.Id, ct);
                    }
                    catch (Exception ex)
                    {
                        await _collector.FailOutboxAsync(item.Id, ex.Message, ct);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Outbox loop error");
            }

            try
            {
                await Task.Delay(TimeSpan.FromSeconds(2), ct);
            }
            catch
            {
                // ignore
            }
        }
    }

    private async Task SendOutboxItemAsync(OutgoingTelegramMessage item, CancellationToken ct)
    {
        if (item.Type == "close_request")
        {
            var ticketId = item.TicketId ?? ExtractTicketId(item.PayloadJson) ?? 0;
            var keyboard = new InlineKeyboardMarkup(new[]
            {
                new[]
                {
                    InlineKeyboardButton.WithCallbackData("✅ Да", $"keep_open_{ticketId}"),
                    InlineKeyboardButton.WithCallbackData("❌ Нет", $"close_confirm_{ticketId}"),
                }
            });

            await _bot.SendTextMessageAsync(item.ChatId, item.Text ?? $"Нужна ли помощь дальше по тикету #{ticketId}?", parseMode: ParseMode.Html, replyMarkup: keyboard, cancellationToken: ct);
            return;
        }

        if (item.Type == "new_ticket")
        {
            var ticketId = item.TicketId ?? ExtractTicketId(item.PayloadJson) ?? 0;
            var kb = new InlineKeyboardMarkup(new[]
            {
                new[]
                {
                    InlineKeyboardButton.WithCallbackData("👨‍💻 Взять в работу", $"assign:{ticketId}"),
                    InlineKeyboardButton.WithCallbackData("✅ Закрыть", $"close:{ticketId}")
                }
            });

            await _bot.SendTextMessageAsync(item.ChatId, item.Text ?? $"🆕 Новый тикет #{ticketId}", parseMode: ParseMode.Html, replyMarkup: kb, cancellationToken: ct);

            // Если у тикета были вложения, отправим их отдельными сообщениями.
            if (!string.IsNullOrWhiteSpace(item.AttachmentsJson))
            {
                try
                {
                    var attachments = JsonSerializer.Deserialize<List<AttachmentItem>>(item.AttachmentsJson) ?? new();
                    foreach (var a in attachments)
                        await SendAttachmentAsync(item.ChatId, a, ct);
                }
                catch
                {
                    // ignore
                }
            }

            return;
        }

        // default: text + optional attachments
        if (!string.IsNullOrWhiteSpace(item.Text))
        {
            await _bot.SendTextMessageAsync(item.ChatId, item.Text, parseMode: ParseMode.Html, cancellationToken: ct);
        }

        if (!string.IsNullOrWhiteSpace(item.AttachmentsJson))
        {
            var attachments = JsonSerializer.Deserialize<List<AttachmentItem>>(item.AttachmentsJson) ?? new();
            foreach (var a in attachments)
            {
                await SendAttachmentAsync(item.ChatId, a, ct);
            }
        }
    }

    private async Task SendAttachmentAsync(long chatId, AttachmentItem att, CancellationToken ct)
    {
        // Telegram file id (если уже есть)
        if (!string.IsNullOrWhiteSpace(att.FileId))
        {
            var input = global::Telegram.Bot.Types.InputFile.FromFileId(att.FileId);
            if (att.Type == "photo") await _bot.SendPhotoAsync(chatId, input, cancellationToken: ct);
            else if (att.Type == "video") await _bot.SendVideoAsync(chatId, input, cancellationToken: ct);
            else await _bot.SendDocumentAsync(chatId, input, cancellationToken: ct);
            return;
        }

        // WEB URL: скачиваем и отправляем
        if (string.IsNullOrWhiteSpace(att.Url))
            return;

        var baseUrl = _cfg["Collector:BaseUrl"]?.TrimEnd('/') ?? string.Empty;
        var url = att.Url!.StartsWith("http", StringComparison.OrdinalIgnoreCase) ? att.Url! : (baseUrl + att.Url);

        using var http = new HttpClient();
        await using var stream = await http.GetStreamAsync(url, ct);

        var fileName = string.IsNullOrWhiteSpace(att.FileName) ? "file" : att.FileName;
        var inputFile = global::Telegram.Bot.Types.InputFile.FromStream(stream, fileName);

        if (att.Type == "photo") await _bot.SendPhotoAsync(chatId, inputFile, cancellationToken: ct);
        else if (att.Type == "video") await _bot.SendVideoAsync(chatId, inputFile, cancellationToken: ct);
        else await _bot.SendDocumentAsync(chatId, inputFile, cancellationToken: ct);
    }

    private static int? ExtractTicketId(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return null;
        try
        {
            using var doc = JsonDocument.Parse(json);
            if (doc.RootElement.TryGetProperty("ticketId", out var idEl) && idEl.TryGetInt32(out var id))
                return id;
        }
        catch
        {
            // ignore
        }

        return null;
    }

    private async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken ct)
    {
        try
        {
            if (update.Type == UpdateType.CallbackQuery && update.CallbackQuery != null)
            {
                await HandleCallbackAsync(update.CallbackQuery, ct);
                return;
            }

            if (update.Type != UpdateType.Message || update.Message == null)
                return;

            await HandleMessageAsync(update.Message, ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "HandleUpdate error");
        }
    }

    private Task HandleErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken ct)
    {
        var err = exception switch
        {
            ApiRequestException apiEx => $"Telegram API Error: {apiEx.ErrorCode}\n{apiEx.Message}",
            _ => exception.ToString()
        };
        _logger.LogError("Telegram bot error: {Err}", err);
        return Task.CompletedTask;
    }

    private async Task HandleMessageAsync(Message message, CancellationToken ct)
    {
        if (message.From == null)
            return;

        var userId = message.From.Id;
        var text = message.Text ?? string.Empty;

        // /start or main menu
        if (text == "/start")
        {
            await SendWelcomeAsync(message.Chat.Id, ct);
            return;
        }

        // helper reply command in support chat: /t 123 text
        if (text.StartsWith("/t ", StringComparison.OrdinalIgnoreCase))
        {
            await HandleHelperReplyAsync(message, ct);
            return;
        }

        if (text == BotKeyboards.BtnHelp)
        {
            await SendWelcomeAsync(message.Chat.Id, ct);
            return;
        }

        if (text == BotKeyboards.BtnNewTicket)
        {
            await StartNewTicketAsync(message, ct);
            return;
        }

        if (text == BotKeyboards.BtnMyTickets)
        {
            await ShowMyTicketsAsync(message, ct);
            return;
        }

        if (text == BotKeyboards.BtnCloseTicket)
        {
            await CloseTicketByUserAsync(message, ct);
            return;
        }

        // Conversation state from collector
        var session = await _collector.GetSessionAsync(userId, ct);
        if (session != null && session.Step != TelegramConversationStep.None)
        {
            await HandleConversationAsync(message, session, ct);
            return;
        }

        // Otherwise: append to open ticket
        await HandleAdditionalUserMessageAsync(message, ct);
    }

    private async Task SendWelcomeAsync(long chatId, CancellationToken ct)
    {
        var text =
            "<b>Добро пожаловать в HelpDesk бот 👋</b>\n\n" +
            "С помощью этого бота вы можете быстро оставить обращение в техническую поддержку.\n\n" +
            "<b>Как это работает:</b>\n" +
            "1️⃣ Нажмите «Новый тикет» и по шагам заполните форму\n" +
            "2️⃣ После отправки тикета он попадёт к специалистам\n" +
            "3️⃣ Пока тикет открыт, вы можете писать дополнительные сообщения\n" +
            "4️⃣ Когда вопрос будет решён, закройте тикет кнопкой «Закрыть тикет»\n\n" +
            "Если готовы начать — нажмите кнопку ниже 👇";

        await _bot.SendTextMessageAsync(chatId, text, parseMode: ParseMode.Html, replyMarkup: BotKeyboards.MainMenu(), cancellationToken: ct);
    }

    private async Task StartNewTicketAsync(Message message, CancellationToken ct)
    {
        if (message.From == null) return;

        var open = await _collector.GetOpenTicketByTelegramAsync(message.From.Id, ct);
        if (open != null)
        {
            await _bot.SendTextMessageAsync(message.Chat.Id,
                "У вас уже есть открытый тикет. Вы можете дописать сюда дополнительную информацию или закрыть тикет кнопкой «Закрыть тикет».",
                replyMarkup: BotKeyboards.MainMenu(),
                cancellationToken: ct);
            return;
        }

        var session = new TelegramUserSession
        {
            UserId = message.From.Id,
            Username = message.From.Username,
            Step = TelegramConversationStep.Reason,
            DraftJson = JsonSerializer.Serialize(new TicketDraft())
        };

        await _collector.SaveSessionAsync(session, ct);

        await _bot.SendTextMessageAsync(message.Chat.Id,
            "1️⃣ <b>Что вас привело сюда?</b>\nОпишите проблему или вопрос.",
            parseMode: ParseMode.Html,
            replyMarkup: BotKeyboards.Back(),
            cancellationToken: ct);
    }

    private static TicketDraft LoadDraft(TelegramUserSession session)
    {
        try
        {
            return JsonSerializer.Deserialize<TicketDraft>(session.DraftJson) ?? new TicketDraft();
        }
        catch
        {
            return new TicketDraft();
        }
    }

    private static void SaveDraft(TelegramUserSession session, TicketDraft draft)
    {
        session.DraftJson = JsonSerializer.Serialize(draft);
        session.UpdatedAt = DateTime.UtcNow;
    }

    private async Task HandleConversationAsync(Message message, TelegramUserSession session, CancellationToken ct)
    {
        if (message.From == null) return;

        var text = message.Text ?? string.Empty;

        // Back -> cancel
        if (text == BotKeyboards.BtnBack)
        {
            await _collector.DeleteSessionAsync(message.From.Id, ct);
            await _bot.SendTextMessageAsync(message.Chat.Id,
                "Создание тикета отменено. Вы в главном меню.",
                replyMarkup: BotKeyboards.MainMenu(),
                cancellationToken: ct);
            return;
        }

        var draft = LoadDraft(session);

        switch (session.Step)
        {
            case TelegramConversationStep.Reason:
                draft.Reason = text.Trim();
                session.Step = TelegramConversationStep.Phone;
                SaveDraft(session, draft);
                await _collector.SaveSessionAsync(session, ct);

                await _bot.SendTextMessageAsync(message.Chat.Id,
                    "2️⃣ <b>Ваш контактный номер телефона</b>\nПожалуйста, введите номер в удобном формате.",
                    parseMode: ParseMode.Html,
                    replyMarkup: BotKeyboards.Back(),
                    cancellationToken: ct);
                break;

            case TelegramConversationStep.Phone:
                draft.Phone = text.Trim();
                session.Step = TelegramConversationStep.AccountNumber;
                SaveDraft(session, draft);
                await _collector.SaveSessionAsync(session, ct);

                await _bot.SendTextMessageAsync(message.Chat.Id,
                    "3️⃣ <b>Номер лицевого счёта</b>\nУкажите номер договора / лицевого счета.",
                    parseMode: ParseMode.Html,
                    replyMarkup: BotKeyboards.Back(),
                    cancellationToken: ct);
                break;

            case TelegramConversationStep.AccountNumber:
                draft.AccountNumber = text.Trim();
                session.Step = TelegramConversationStep.ProblemType;
                SaveDraft(session, draft);
                await _collector.SaveSessionAsync(session, ct);

                await _bot.SendTextMessageAsync(message.Chat.Id,
                    "4️⃣ <b>С чем проблема?</b>",
                    parseMode: ParseMode.Html,
                    replyMarkup: BotKeyboards.ProblemType(),
                    cancellationToken: ct);
                break;

            case TelegramConversationStep.ProblemType:
                if (text is not (BotKeyboards.BtnInternet or BotKeyboards.BtnTv or BotKeyboards.BtnBoth))
                {
                    await _bot.SendTextMessageAsync(message.Chat.Id, "Пожалуйста, выберите вариант с клавиатуры.", cancellationToken: ct);
                    return;
                }

                draft.ProblemType = text;
                session.Step = TelegramConversationStep.Comment;
                SaveDraft(session, draft);
                await _collector.SaveSessionAsync(session, ct);

                await _bot.SendTextMessageAsync(message.Chat.Id,
                    "5️⃣ <b>Комментарий к обращению</b>\nОпишите проблему подробнее.",
                    parseMode: ParseMode.Html,
                    replyMarkup: BotKeyboards.Back(),
                    cancellationToken: ct);
                break;

            case TelegramConversationStep.Comment:
                draft.Comment = text.Trim();
                session.Step = TelegramConversationStep.Attachments;
                SaveDraft(session, draft);
                await _collector.SaveSessionAsync(session, ct);

                await _bot.SendTextMessageAsync(message.Chat.Id,
                    "6️⃣ <b>Вложения</b>\n" +
                    "Если есть фото/файлы — отправьте их сообщениями.\n" +
                    "Когда закончите, нажмите «Готово». Если вложения не нужны — нажмите «Пропустить».",
                    parseMode: ParseMode.Html,
                    replyMarkup: BotKeyboards.Attachments(),
                    cancellationToken: ct);
                break;

            case TelegramConversationStep.Attachments:
                await HandleAttachmentsStepAsync(message, session, draft, ct);
                break;
        }
    }

    private async Task HandleAttachmentsStepAsync(Message message, TelegramUserSession session, TicketDraft draft, CancellationToken ct)
    {
        if (message.From == null) return;

        if (message.Text == BotKeyboards.BtnDone || message.Text == BotKeyboards.BtnSkip)
        {
            await FinalizeTicketAsync(message, draft, ct);
            await _collector.DeleteSessionAsync(message.From.Id, ct);
            return;
        }

        var added = false;

        if (message.Photo != null && message.Photo.Any())
        {
            // берём самый большой размер
            var photo = message.Photo.OrderByDescending(p => p.FileSize ?? 0).First();
            var att = await DownloadAndStoreTelegramFileAsync(
                fileId: photo.FileId,
                type: "photo",
                fileName: null,
                contentType: "image/jpeg",
                ct: ct);

            draft.Attachments.Add(att);
            added = true;
        }

        if (message.Document != null)
        {
            var isImage = !string.IsNullOrWhiteSpace(message.Document.MimeType) && message.Document.MimeType.StartsWith("image/", StringComparison.OrdinalIgnoreCase);
            var type = isImage ? "photo" : "document";
            var att = await DownloadAndStoreTelegramFileAsync(
                fileId: message.Document.FileId,
                type: type,
                fileName: message.Document.FileName,
                contentType: message.Document.MimeType,
                ct: ct);

            draft.Attachments.Add(att);
            added = true;
        }

        if (added)
        {
            SaveDraft(session, draft);
            await _collector.SaveSessionAsync(session, ct);
            await _bot.SendTextMessageAsync(message.Chat.Id, "📎 Вложение добавлено. Можете отправить ещё или нажать «Готово».", cancellationToken: ct);
        }
        else
        {
            await _bot.SendTextMessageAsync(message.Chat.Id, "Отправьте фото или документ, либо нажмите «Готово» / «Пропустить».", cancellationToken: ct);
        }
    }

    private async Task FinalizeTicketAsync(Message message, TicketDraft draft, CancellationToken ct)
    {
        if (message.From == null) return;

        var req = new CreateTicketRequest
        {
            Source = "telegram",
            TelegramUserId = message.From.Id,
            TelegramUsername = message.From.Username,
            TelegramFullName = $"{message.From.FirstName} {message.From.LastName}".Trim(),
            Reason = draft.Reason,
            Phone = draft.Phone,
            AccountNumber = draft.AccountNumber,
            ProblemType = draft.ProblemType,
            Comment = draft.Comment,
            Attachments = draft.Attachments,
            Photo = draft.Attachments.Any() ? $"Вложения из Telegram ({draft.Attachments.Count})" : null
        };

        var ticket = await _collector.CreateTicketAsync(req, ct);

        await _bot.SendTextMessageAsync(message.Chat.Id,
            $"✅ Ваш тикет №{ticket.Id} успешно создан!\n\n" +
            "Специалист поддержки скоро свяжется с вами.\n" +
            "Вы можете отправлять дополнительные сообщения по этому тикету прямо в чат, пока он открыт.",
            replyMarkup: BotKeyboards.MainMenu(),
            cancellationToken: ct);
    }

    private async Task ShowMyTicketsAsync(Message message, CancellationToken ct)
    {
        if (message.From == null) return;

        var tickets = await _collector.GetTicketsByTelegramAsync(message.From.Id, 10, ct);
        if (!tickets.Any())
        {
            await _bot.SendTextMessageAsync(message.Chat.Id, "У вас пока нет обращений.", replyMarkup: BotKeyboards.MainMenu(), cancellationToken: ct);
            return;
        }

        var lines = new List<string> { "<b>Ваши последние тикеты:</b>" };
        foreach (var t in tickets)
        {
            var statusEmoji = t.Status == TicketStatus.Open ? "🟢" : "⚪️";
            lines.Add($"{statusEmoji} #{t.Id} • {t.ProblemType} • {t.CreatedAt:dd.MM.yyyy HH:mm} • {t.Status}");
        }

        await _bot.SendTextMessageAsync(message.Chat.Id, string.Join("\n", lines), parseMode: ParseMode.Html, replyMarkup: BotKeyboards.MainMenu(), cancellationToken: ct);
    }

    private async Task CloseTicketByUserAsync(Message message, CancellationToken ct)
    {
        if (message.From == null) return;

        var open = await _collector.GetOpenTicketByTelegramAsync(message.From.Id, ct);
        if (open == null)
        {
            await _bot.SendTextMessageAsync(message.Chat.Id, "У вас нет открытых тикетов.", replyMarkup: BotKeyboards.MainMenu(), cancellationToken: ct);
            return;
        }

        var ok = await _collector.CloseTicketAsync(open.Id, "Закрыт пользователем", ct);
        if (ok)
        {
            await _bot.SendTextMessageAsync(message.Chat.Id, $"✅ Тикет #{open.Id} закрыт.", replyMarkup: BotKeyboards.MainMenu(), cancellationToken: ct);
        }
        else
        {
            await _bot.SendTextMessageAsync(message.Chat.Id, "Не удалось закрыть тикет.", replyMarkup: BotKeyboards.MainMenu(), cancellationToken: ct);
        }
    }

    private async Task HandleAdditionalUserMessageAsync(Message message, CancellationToken ct)
    {
        if (message.From == null) return;

        var open = await _collector.GetOpenTicketByTelegramAsync(message.From.Id, ct);
        if (open == null)
        {
            await _bot.SendTextMessageAsync(message.Chat.Id,
                "У вас нет открытых тикетов. Нажмите «Новый тикет», чтобы создать обращение.",
                replyMarkup: BotKeyboards.MainMenu(),
                cancellationToken: ct);
            return;
        }

        // Text + attachments
        var attachments = new List<AttachmentItem>();

        if (message.Photo != null && message.Photo.Any())
        {
            var photo = message.Photo.OrderByDescending(p => p.FileSize ?? 0).First();
            attachments.Add(await DownloadAndStoreTelegramFileAsync(photo.FileId, "photo", null, "image/jpeg", ct));
        }

        if (message.Document != null)
        {
            var isImage = !string.IsNullOrWhiteSpace(message.Document.MimeType) && message.Document.MimeType.StartsWith("image/", StringComparison.OrdinalIgnoreCase);
            var type = isImage ? "photo" : "document";
            attachments.Add(await DownloadAndStoreTelegramFileAsync(message.Document.FileId, type, message.Document.FileName, message.Document.MimeType, ct));
        }

        await _collector.AddMessageAsync(open.Id, new AddMessageRequest
        {
            FromRole = "user",
            FromUserId = message.From.Id,
            FromUsername = message.From.Username,
            Text = message.Text,
            Attachments = attachments.Any() ? attachments : null,
            EnqueueToSupportChat = true
        }, ct);

        await _bot.SendTextMessageAsync(message.Chat.Id, "✅ Сообщение добавлено в тикет. Я передал специалисту.", cancellationToken: ct);
    }

    /// <summary>
    /// Делает вложение стабильным для WEB: скачивает файл из Telegram и загружает в Collector (/uploads/...).
    /// При любых ошибках возвращает AttachmentItem только с FileId (как fallback).
    /// </summary>
    private async Task<AttachmentItem> DownloadAndStoreTelegramFileAsync(string fileId, string type, string? fileName, string? contentType, CancellationToken ct)
    {
        var att = new AttachmentItem
        {
            Type = type,
            FileId = fileId,
            FileName = fileName
        };

        try
        {
            var tgFile = await _bot.GetFileAsync(fileId, ct);
            if (string.IsNullOrWhiteSpace(tgFile.FilePath))
                return att;

            var name = fileName;
            if (string.IsNullOrWhiteSpace(name))
                name = Path.GetFileName(tgFile.FilePath);
            if (string.IsNullOrWhiteSpace(name))
                name = $"{type}_{DateTime.UtcNow:yyyyMMdd_HHmmss}_{Guid.NewGuid():N}.bin";

            await using var ms = new MemoryStream();
            await _bot.DownloadFileAsync(tgFile.FilePath, ms, ct);
            ms.Position = 0;

            var ctResolved = string.IsNullOrWhiteSpace(contentType) ? GuessContentTypeFromFileName(name) : contentType;
            var uploaded = await _collector.UploadFileAsync(ms, name, ctResolved!, ct);

            if (!string.IsNullOrWhiteSpace(uploaded.Url))
                att.Url = uploaded.Url;

            // fileName оставим, чтобы UI мог показать имя
            att.FileName = fileName ?? name;
        }
        catch
        {
            // fallback: только FileId
        }

        return att;
    }

    private static string GuessContentTypeFromFileName(string fileName)
    {
        var ext = Path.GetExtension(fileName).ToLowerInvariant();
        return ext switch
        {
            ".jpg" or ".jpeg" => "image/jpeg",
            ".png" => "image/png",
            ".webp" => "image/webp",
            ".gif" => "image/gif",
            ".pdf" => "application/pdf",
            ".txt" => "text/plain",
            ".mp4" => "video/mp4",
            _ => "application/octet-stream"
        };
    }

    private async Task HandleHelperReplyAsync(Message message, CancellationToken ct)
    {
        // Allowed only in support chat and by helper usernames (if configured)
        var fromUsername = message.From?.Username ?? string.Empty;
        var isHelper = string.IsNullOrWhiteSpace(fromUsername) ? false : _helperUsernames.Contains(fromUsername);

        if (_supportChatId != 0 && message.Chat.Id != _supportChatId)
        {
            await _bot.SendTextMessageAsync(message.Chat.Id, "Команда /t доступна только в чате поддержки.", cancellationToken: ct);
            return;
        }

        if (_helperUsernames.Any() && !isHelper)
        {
            await _bot.SendTextMessageAsync(message.Chat.Id, "Нет доступа.", cancellationToken: ct);
            return;
        }

        var text = message.Text ?? string.Empty;
        var parts = text.Split(' ', 3, StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length < 3 || !int.TryParse(parts[1], out var ticketId))
        {
            await _bot.SendTextMessageAsync(message.Chat.Id, "Формат: /t <ticketId> <текст>", cancellationToken: ct);
            return;
        }

        var payload = parts[2];

        await _collector.AddMessageAsync(ticketId, new AddMessageRequest
        {
            FromRole = "helper",
            FromUserId = message.From!.Id,
            FromUsername = message.From.Username,
            Text = payload,
            EnqueueToTelegramUser = true
        }, ct);

        await _bot.SendTextMessageAsync(message.Chat.Id, $"✅ Отправлено пользователю по тикету #{ticketId}.", cancellationToken: ct);
    }

    /// <summary>
    /// CallbackQuery must be answered quickly; otherwise Telegram returns:
    /// "query is too old and response timeout expired". We don't want such
    /// transient UI errors to break the update handler.
    /// </summary>
    private async Task SafeAnswerCallbackAsync(string callbackQueryId, string? text, bool showAlert, CancellationToken ct)
    {
        try
        {
            await _bot.AnswerCallbackQueryAsync(callbackQueryId, text, showAlert: showAlert, cancellationToken: ct);
        }
        catch (ApiRequestException ex) when (
            ex.Message.Contains("query is too old", StringComparison.OrdinalIgnoreCase) ||
            ex.Message.Contains("query ID is invalid", StringComparison.OrdinalIgnoreCase) ||
            ex.Message.Contains("QUERY_ID_INVALID", StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogDebug(ex, "Callback query expired/invalid; ignoring.");
        }
        catch (ApiRequestException ex) when (
            ex.Message.Contains("query has been answered", StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogDebug(ex, "Callback query already answered; ignoring.");
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to answer callback query; ignoring.");
        }
    }

    private Task SafeAnswerCallbackAsync(string callbackQueryId, string? text = null, CancellationToken ct = default)
        => SafeAnswerCallbackAsync(callbackQueryId, text, showAlert: false, ct);

    private Task SafeAnswerCallbackAlertAsync(string callbackQueryId, string? text, CancellationToken ct = default)
        => SafeAnswerCallbackAsync(callbackQueryId, text, showAlert: true, ct);

    private async Task HandleCallbackAsync(CallbackQuery query, CancellationToken ct)
    {
        if (query.Data == null) return;

        var data = query.Data;
        var chatId = query.Message?.Chat.Id ?? 0;

        // assign:123 or close:123
        if (data.StartsWith("assign:", StringComparison.OrdinalIgnoreCase))
        {
            var ticketId = int.Parse(data.Split(':')[1]);

            // permissions: only support chat helpers
            if (_supportChatId != 0 && chatId != _supportChatId)
            {
                await SafeAnswerCallbackAlertAsync(query.Id, "Недостаточно прав", ct);
                return;
            }

            var helperName = $"{query.From.FirstName} {query.From.LastName}".Trim();
            var ok = await _collector.TakeTicketAsync(ticketId, new AssignTicketRequest
            {
                HelperTelegramId = query.From.Id,
                HelperName = helperName,
                HelperUsername = query.From.Username
            }, ct);

            if (!ok)
            {
                await SafeAnswerCallbackAlertAsync(query.Id, "Не удалось (возможно уже взяли)", ct);
                return;
            }
            await SafeAnswerCallbackAsync(query.Id, "Вы взяли тикет", ct);
            try { await _bot.EditMessageReplyMarkupAsync(chatId, query.Message!.MessageId, replyMarkup: null, cancellationToken: ct); } catch { }
            return;
        }

        if (data.StartsWith("close:", StringComparison.OrdinalIgnoreCase))
        {
            var ticketId = int.Parse(data.Split(':')[1]);

            var (ok, err) = await _collector.RequestCloseAsync(ticketId, ct);
            if (!ok)
            {
                await SafeAnswerCallbackAlertAsync(query.Id, $"Не удалось: {err}", ct);
                return;
            }

            await SafeAnswerCallbackAsync(query.Id, "Запрос на закрытие отправлен", ct);
            return;
        }

        // keep_open_123 / close_confirm_123
        if (data.StartsWith("keep_open_", StringComparison.OrdinalIgnoreCase))
        {
            if (!int.TryParse(data.Replace("keep_open_", ""), out var ticketId))
                return;

            var ok = await _collector.ConfirmKeepOpenAsync(ticketId, ct);
            if (!ok)
            {
                await SafeAnswerCallbackAlertAsync(query.Id, "Не удалось", ct);
                return;
            }

            await SafeAnswerCallbackAsync(query.Id, "Ок, тикет остаётся открытым", ct);
            try { await _bot.EditMessageReplyMarkupAsync(chatId, query.Message!.MessageId, replyMarkup: null, cancellationToken: ct); } catch { }
            return;
        }

        if (data.StartsWith("close_confirm_", StringComparison.OrdinalIgnoreCase))
        {
            if (!int.TryParse(data.Replace("close_confirm_", ""), out var ticketId))
                return;

            var ok = await _collector.ConfirmCloseAsync(ticketId, ct);
            if (!ok)
            {
                await SafeAnswerCallbackAlertAsync(query.Id, "Не удалось", ct);
                return;
            }

            await SafeAnswerCallbackAsync(query.Id, "Тикет закрыт", ct);
            try { await _bot.EditMessageReplyMarkupAsync(chatId, query.Message!.MessageId, replyMarkup: null, cancellationToken: ct); } catch { }
            return;
        }
    }
}
