using Telegram.Bot.Types.ReplyMarkups;

namespace Helpdesk.Bot.Telegram.Bot;

public static class BotKeyboards
{
    public const string BtnNewTicket = "🆕 Новый тикет";
    public const string BtnMyTickets = "📜 Мои тикеты";
    public const string BtnHelp = "ℹ️ Как это работает";
    public const string BtnContacts = "📞 Контакты";
    public const string BtnCloseTicket = "✅ Закрыть тикет";
    public const string BtnBack = "🔙 Вернуться назад";

    public const string BtnInternet = "🌐 Интернет";
    public const string BtnTv = "📺 Телевидение";
    public const string BtnBoth = "🌐+📺 Интернет и ТВ";

    public const string BtnSkip = "⏭ Пропустить";
    public const string BtnDone = "✅ Готово";

    public static ReplyKeyboardMarkup MainMenu()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new KeyboardButton[] { BtnNewTicket, BtnMyTickets },
            new KeyboardButton[] { BtnHelp, BtnContacts },
            new KeyboardButton[] { BtnCloseTicket }
        })
        {
            ResizeKeyboard = true
        };
    }

    public static ReplyKeyboardMarkup Back()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new KeyboardButton[] { BtnBack }
        })
        {
            ResizeKeyboard = true
        };
    }

    public static ReplyKeyboardMarkup ProblemType()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new KeyboardButton[] { BtnInternet, BtnTv },
            new KeyboardButton[] { BtnBoth },
            new KeyboardButton[] { BtnBack }
        })
        {
            ResizeKeyboard = true
        };
    }

    public static ReplyKeyboardMarkup Attachments()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new KeyboardButton[] { BtnDone, BtnSkip },
            new KeyboardButton[] { BtnBack }
        })
        {
            ResizeKeyboard = true
        };
    }
}
